# CDC 2017 Code

The code contained in these folders are used to generate the figures in:

J. D. Gleason, A. P. Vinod, M. M. K. Oishi "Underapproximation of Reach-Avoid 
Sets for Discrete-Time Stochastic Systems via Lagrangian Methods", in the
*Proceedings of the 2017 IEEE Conference on Decision and Control*, Dec. 2012

## Dependencies

  - MPT 3.0 (http://people.ee.ethz.ch/~mpt/3/)
  - Gurobi Optimizer 6.5.2 (http://www.gurobi.com/downloads/gurobi-optimizer)

## Outline

The scripts that will generate Figures 2, 3, and 4 can be found in the 
`./tests/` directory. All relevant source code needed by the files can be found 
in `./src/`. All test files will add the `./src/` directory to the path and 
remove this directory after completion. So there is no need to add any folders
to the path.

## Test Scripts

### `./tests/fig2.m`

MATLAB m-file used to generate Figure 2. Figure 2 is a comparison of the 
reach-avoid sets obtained using dynamic programming principles and the 
Lagrangian approximations detailed in the paper. This demonstrates the
conservativeness of the Lagrangian methods and how the conservativeness 
increases with the time horizon or simulation length of interest.

### `./tests/fig3.m`

MATLAB m-file used to generate Figure 3. Figure 3 demenstrates that the 
Lagrangian underapproximation provides tight results for systems with low
disturbance variances.

### `./tests/fig4.m`

MATLAB m-file used to generate Figure 4. Figure 4 shows a 2-d slice of the 
Lagrangian underapproximation for the 4-dimensional sattelite rendezvous-docking
problem.

Because of limitations in the ability to solve the vertex-facet enumeration 
problem systems with a substantail vertex/facet count, the code suffers from 
repeatability issues. The following is an important excerpt from the header of 
`fig4.m` describing the issue and the attempts to improve repeatability. 
This can be seen by executing `help fig4.m`.

    The vertex-facet enumaration problem for polytopes with high 
    vertex/facet counts is a challenging task. The toolboxes in use,
    specifically MPT, use CDDMEX to solve this problem. The use of specific
    solvers help enhance repeatability.

    To enhance repeatability we do the following:
       1) We have saved a version of our polytopic approximation of the
          bounded disturbance set, Eset, to a mat file,
          ../var/mats/ellipsoid_overapprox.mat

          In order to solve the rendezvous-docking problem we must determine
          a polytopic approximation of the bounded disturbance set. This 
          polytopic approximation is generated randomly using 
          polytopicEllipseFromRandomDirections. Because of the random
          support function generation used, the bounded disturbance ellipse
          varies in the tightness of its approximation.

       2) We are using the Gurobi Optimizer
          (http://www.gurobi.com/downloads/gurobi-optimizer) as the default
          solver for LP, QP, MILP, MIQP

       3) We have saved the workspace---including the bouded ellipse, the
          lagran reach-avoid set underapproximations, simulation time, and
          more---into a mat file, /var/mats/cwh_save.mat. This will allow for
          exact recreation of Figure 4.