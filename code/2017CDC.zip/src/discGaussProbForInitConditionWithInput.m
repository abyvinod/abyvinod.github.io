function meshTransProb = discGaussProbForInitConditionWithInput(x0,mesh,...
                           outerMesh,outerMeshDim,input,stateFun,mu,sigma)
%                       
% function meshTransProb = discGaussProbForInitConditionWithInput(x0,mesh,...
%                            outerMesh,outerMeshDim,input,stateFun,mu,sigma)
mins = [min(mesh(:,1)),min(mesh(:,2))];
maxs = [max(mesh(:,1)),max(mesh(:,2))];
newMu = stateFun(x0,input,mu);
inside = 1;
for i = 1:length(mins)
    if(newMu(i) < mins(i) || newMu(i) > maxs(i))
%         inside = 0;
        break;
    end
end

if(inside)
    newMu = stateFun(x0,input,mu);
    prob = mvncdf(outerMesh,newMu',sigma);
    prob = reshape(prob,outerMeshDim);
    prob = diff(diff(prob,1,2));
    prob = reshape(prob,[],1)';                                            
else
    prob = zeros(1,size(mesh,1));
end
% discGaussProb = zeros(size(input,2),size(mesh,1));

% newMu = stateFun(x0,input,mu);
% prob = mvncdf(outerMesh,newMu',sigma);
% prob = reshape(prob,outerMeshDim);
% prob = diff(diff(prob,1,2));
% prob = reshape(prob,[],1)';
meshTransProb = prob;                                                 
                                                   
end