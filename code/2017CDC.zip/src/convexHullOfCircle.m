function hull = convexHullOfCircle(radius, nVerts)


phis = linspace(0,2*pi,nVerts+1);
phis = phis(1:end-1);

verts = zeros(length(phis),2);
for i = 1:length(phis)
    verts(i,:) = [radius*cos(phis(i)), radius*sin(phis(i))];
end

hull = Polyhedron(verts);

end