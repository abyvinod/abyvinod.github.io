function P = polytopicEllipseFromRandomDirections(Sigma, ndirs)
n = size(Sigma,1);
Ahalf = zeros(ndirs/2+n, n);
bhalf = zeros(ndirs/2+n, 1);
Ahalf(1:n,:) = eye(n)';
bhalf(1:n) = diag(sqrt(Sigma));
% figure()
for i = n+1:ndirs/2+n
    direction = 2 * randn(1,n) - 1;
    direction = direction ./ sqrt(direction * direction');
    Ahalf(i,:) = direction;
    bhalf(i) = direction * sqrt(Sigma) * direction';
%     hold on;
%     scatter(direction(1),direction(2))
end
A = [Ahalf;-Ahalf];
b = [bhalf;bhalf];

P = Polyhedron(A,b);
minVRep(P);
% hold off;
    
