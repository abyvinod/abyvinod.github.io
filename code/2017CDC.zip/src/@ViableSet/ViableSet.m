classdef ViableSet
%
% class ViableSet
%
%   Description:
%   ============
%   A class to store usefull information about a viable set.
%
    properties (SetAccess = private)
        time
        mesh
        meshDims
        meshViab
        meshPolicy
    end
    
    methods
        function obj = ViableSet(time,mesh,meshViab,meshPolicy,meshDims)
            if(nargin < 4)
                obj.time = time;
                obj.mesh = mesh;
                obj.meshViab = meshViab;
                obj.meshPolicy = cell(size(mesh,1),1);
                obj.meshDims = ViableSet.getMeshDimensions(mesh);
            elseif(nargin < 5)
                obj.time = time;
                obj.mesh = mesh;
                obj.meshViab = meshViab;
                obj.meshPolicy = meshPolicy;
                obj.meshDims = ViableSet.getMeshDimensions(mesh);
            else
                obj.time = time;
                obj.mesh = mesh;
                obj.meshViab = meshViab;
                obj.meshPolicy = meshPolicy;
                obj.meshDims = meshDims;
            end
            
        end
    end
    
    methods (Static)
        [meshDims] = getMeshDimensions(mesh);
    end
end