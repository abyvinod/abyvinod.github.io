function plotSet(obj,)

mesh = obj.mesh;
meshDims = obj.meshDims;
viabProb = obj.meshViab;



end