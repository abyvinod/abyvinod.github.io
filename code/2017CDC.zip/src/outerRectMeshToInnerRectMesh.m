function innerMesh = outerRectMeshToInnerRectMesh(outerMesh)

nCols = size(outerMesh,2);
gridVectors = cell(1,size(outerMesh,2));
tempMesh = outerMesh;
for i = 1:nCols
    for m = 1:nCols
        tempMesh = sortrows(tempMesh,m);
    end
    xVec = zeros(size(tempMesh(:,1)))';
    j = 2;
    xVec(1) = tempMesh(1,1);
    while(j <= length(xVec))
        if(isempty(find(xVec(1:j-1) == tempMesh(j,1),1)))
            xVec(j) = tempMesh(j,1);
            j = j + 1;
        else
            break;
        end
    end
    xVec = xVec(1:j - 1);
    xVec = xVec(1:j - 2) + diff(xVec)/2;
    gridVectors{i} = xVec;
    tempMesh = [tempMesh(:,2:nCols), tempMesh(:,1)];
end

innerMesh = makeRectMeshFromGridVectors(gridVectors);

end
