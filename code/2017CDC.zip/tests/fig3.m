%
% File name: fig3.m
% Authors: Joseph D. Gleason
%
% Description:
% ============
% This MATLAB script will generate Figure 3 from
% J. D. Gleason, A. P. Vinod, M. M. K. Oishi, "Underapproximation of 
% Reach-Avoid Sets for Discrete-Time Stochastic Systems via Lagrangian 
% Methods", Proceedings of the 2017 Conference on Decision and Control, 
% Dec. 2017
%
% Dependencies:
% =============
%    - mpt3.0
%

%% Problem
% Comparison between low variance solutions of reach-avoid sets using
% dynamic programming and Lagrangian Underapproximation

%% Dynamic Programming
%% Init
close all
clearvars
clc

addpath('../src')

%% Problem parameters
% Parameters, etc.
dp_timer = tic;
T = 0.25;                    % discretization time-step
endTime = 1.25;              % end time (or start for backwards computing)
nT = int16(endTime / T) + 1; % number of time steps
nT = double(nT);

% level set
beta = 0.8;

% Base mean and variance
sigma_scale = 1e-5;
sigma = sigma_scale*eye(2);
mu = [0,0]';

%% Dynamic programming mesh creation
% x1 and x2 outer vectors
x1OuterVec = -1.025:0.05:1.025;
x2OuterVec = -1.025:0.05:1.025;

% input vectors
u = -0.1:0.1:0.1;

% making meshes
outerMesh = makeRectMeshFromGridVectors({x1OuterVec,x2OuterVec});
outerMeshDim = [length(x1OuterVec),length(x2OuterVec)];
mesh = outerRectMeshToInnerRectMesh(outerMesh);
meshDims = ViableSet.getMeshDimensions(mesh);

%% Double Integrator Dynamics
% state dynamics function
stateFun = @(x,u,w) [1,T;0,1] * x + [T^2 / 2; T] * u + w;

%% Viable Set computations
% Initialize Viable Set Cell Array
ViableSets = cell(1,nT);

%Initial Viable Set
ViableSets{1} = ViableSet(endTime,mesh,ones(size(mesh,1),1));
timeVec = linspace(endTime,0,nT);

% Viable set computation loop
tic
for i = 2:nT
    time = timeVec(i);
    ViableSets{i} = backViableSetComputation(time,mesh,outerMesh,outerMeshDim,u',...
                                             stateFun,mu,sigma,ViableSets{i-1});
end

x1 = reshape(mesh(:,1),meshDims);
x2 = reshape(mesh(:,2),meshDims);

dp_simtime = toc(dp_timer);

fprintf('Simulation time for Dynamic Programming: %1.3f seconds\n', ...
    dp_simtime);


%% Polytopic approximations

lg_timer = tic;


% Safe set K |x1| < 1, |x2| < 1
K = Polyhedron('lb', [-1; -1], 'ub', [1; 1]);

% Input Space
uScale = 0.1;
U = Polyhedron('lb', -1*uScale, 'ub', 1*uScale);

sys = LTISystem('A', [1, T; 0, 1], 'B', [T^2/2; T]);

% Disturbance Space
r2 = chi2inv(beta^(1/(nT-1)), 2);
W = convexHullOfCircle(sqrt(sigma_scale*r2), 12);

%% Lagrangian Reach-Avoid Set Computation
% Terminal reach-avoid set
RA = K;
simTimer = tic;
for j = 1:nT-1
    newTarget = RA - W;
    S = sys.reachableSet('X', newTarget, ...
        'U', U, ...
        'N', 1, ...
        'direction', 'backward');
    RA = intersect(S, K);
end
RAset = RA;

lg_simtime = toc(lg_timer);

fprintf('Simulation time for Lagrangian Underapproximation: %1.3f seconds\n', ...
    lg_simtime);

%% Figure plotting
hf = figure(3);
box on;
hold on;
plot(K, 'color', 'y')
contourf(x1,x2,reshape(ViableSets{6}.meshViab,meshDims),[beta,beta], 'b', ...
    'FaceColor', 'b');
plot(RAset, 'color', 'g', 'LineStyle', '--')
hold off;

hf.Units = 'inches';
hf.PaperUnits = 'inches';

legend('$\mathcal{K}$','$\mathcal{L}_{N}$','$\mathcal{D}_{N}(\mathcal{K},\mathcal{K},\mathcal{E})$');
hf.Children(1).Interpreter = 'latex';

ha = gca;
hl = hf.Children(1);
hl.Orientation = 'horizontal';
hl.EdgeColor = [1,1,1];

ha.XLabel.String = '$x_{1}$';
ha.YLabel.String = '$x_{2}$';
ha.XLabel.Interpreter = 'latex';
ha.YLabel.Interpreter = 'latex';

hl.Position = [ha.Position(1), ha.Position(2)+ha.Position(4)+0.02, ha.Position(3), hl.Position(4)];



%% Clean path additions
rmpath('../src')