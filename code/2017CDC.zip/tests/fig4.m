%
% File name: fig4.m
% Authors: Abraham P. Vinod, Joseph D. Gleason
%
% Description:
% ============
% This MATLAB script will generate Figure 4 from
% J. D. Gleason, A. P. Vinod, M. M. K. Oishi, "Underapproximation of 
% Reach-Avoid Sets for Discrete-Time Stochastic Systems via Lagrangian 
% Methods", Proceedings of the 2017 Conference on Decision and Control, 
% Dec. 2017
%
% Dependencies:
% =============
%    - mpt3.0
%    - Gurobi Optimizer (http://www.gurobi.com/downloads/gurobi-optimizer)
%
%
% Notes: 
% ======
% The vertex-facet enumaration problem for polytopes with high 
% vertex/facet counts is a challenging task. The toolboxes in use,
% specifically MPT, use CDDMEX to solve this problem. The use of specific
% solvers help enhance repeatability.
%
% To enhance repeatability we do the following:
%    1) We have saved a version of our polytopic approximation of the
%       bounded disturbance set, Eset, to a mat file,
%       ../var/mats/ellipsoid_overapprox.mat
%
%       In order to solve the rendezvous-docking problem we must determine
%       a polytopic approximation of the bounded disturbance set. This 
%       polytopic approximation is generated randomly using 
%       polytopicEllipseFromRandomDirections. Because of the random
%       support function generation used, the bounded disturbance ellipse
%       varies in the tightness of its approximation.
%
%    2) We are using the Gurobi Optimizer
%       (http://www.gurobi.com/downloads/gurobi-optimizer) as the default
%       solver for LP, QP, MILP, MIQP
%
%    3) We have saved the workspace---including the bouded ellipse, the
%       lagran reach-avoid set underapproximations, simulation time, and
%       more---into a mat file, /var/mats/cwh_save.mat. This will allow for
%       exact recreation of Figure 4.
%
%


%% Problem
% Reach-avoid solution for the spacecraft rendezvous-docking problem

%% Solution
% Construct an appropriate E for the desired stochastic reach-avoid level-set
% Implement the robust reach-avoid set iteration to compute the
% underapproximation

%% Init
% 1. Since polytopes are 4D, we use the slicing point [v_x,v_y] = 0
% 2. Ellipsoid is created using the concept of spirals and saved in a mat file
% 3. Umax has been set to 0.1

close all
clear all
clc

evalc('mpt_init');              % MPT init
precompute_timer = tic;

addpath('../src');

%% Problem parameters
beta = 0.8;                     % Desired stochastic reach-avoid set level

%% CWH dynamics --- Euler discretization of the continuous-time system 
%see  W. Wiesel, Spaceflight Dynamics. New York: McGraw-Hill, 1989.
% State of the system is [x,y,v_x,v_y]

T = 20;                         % sampling period in sec.
R = 850 + 6378.1;               % Orbital radius in m
G= 6.673e-11;                   % Universal gravitational constant                                           
M=5.9472e24;                    % Mass of the earth
mu = G*M/(1000^3);              % Gravitation constant for the pull of the earth
omega = sqrt(mu/(R^3));         % Angular velocity in the orbit

mc = 300;                       % Mass of the chief kg

tau = omega*T;                  
Btemp = [0 0; 0 0;1/mc 0; 0 1/mc];
A = [4 - 3*cos(tau), 0, sin(tau)/omega, (2/omega)*(1-cos(tau));
        6*(sin(tau) - tau), 1, -(2/omega)*(1-cos(tau)), (4*sin(tau)-3*tau)/omega;
      3*omega*sin(tau), 0, cos(tau), 2*sin(tau);
      -6*omega*(1-cos(tau)), 0, -2*sin(tau), 4*cos(tau)-3];
  
B_int = @(t,~) [          4*t - 3*sin(omega*t)/omega, 0,               -cos(omega*t)/omega^2,            (2/omega)*(t - sin(omega*t)/omega);
                6*(sin(omega*t)/omega - omega*t^2/2), t, -(2/omega)*(t - sin(omega*t)/omega), (-4*cos(omega*t)/omega - 3*omega*t^2/2)/omega;
                                     -3*cos(omega*t), 0,                  sin(omega*t)/omega,                         -2*cos(omega*t)/omega;
                   -6*omega*(t - sin(omega*t)/omega), 0,                2*cos(omega*t)/omega,                    4*sin(omega*t)/omega - 3*t];

B = (B_int(T,omega) - B_int(0,omega))*Btemp;

%% System parameters
umax=0.1;
U = Polyhedron('lb', -[umax;umax], 'ub', [umax;umax]);

% Safe Set --- LoS cone K
% |x|<=y and y\in[0,ymax] and |vx|<=vxmax and |vy|<=vymax
ymax=2;
vxmax=0.5;
vymax=0.5;
Ap = [1, 1, 0, 0;           
     -1, 1, 0, 0; 
      0, -1, 0, 0;
      0, 0, 1,0;
      0, 0,-1,0;
      0, 0, 0,1;
      0, 0, 0,-1];
bp = [0;
      0;
      ymax;
      vxmax;
      vxmax;
      vymax;
      vymax];
K = Polyhedron(Ap, bp);
minHRep(K);                         % Get vertex representation of K
minVRep(K);                         % Get vertex representation of K

% Target set --- T
% Box centered [-0.1,0.1]x[-0.1,0]x[-0.01,0.01]x[-0.01,0.01]
% Creating the polyhedron using the upper and lower bounds
T = Polyhedron('lb', [-0.1; -0.1; -0.01; -0.01], 'ub', [0.1; 0; 0.01; 0.01]);
minVRep(T);                         % Get vertex representation of K

% Disturbance set --- Eset\subseteq W
sigs = [1e-4, 1e-4, 5e-8, 5e-8];    % sigma^2 values
R2 = chi2inv(beta^(1/5), 2);        % Computation of R^2
ellips_rads = sigs * R2;            % Diagonal values of the shape matrix

%% Bounded Disturbance Ellipsoid Generation
% Two methods can be used:
% 1) Generate polytopic 4d ellipsoid representation via random direction 
% generation (uncomment line below)
% Eset = polytopicEllipseFromRandomDirections(diag(ellips_rads), 600);

% 2) Use the ellipsoid from the paper saved in the mat file:
% ../var/mat/ellipsoid_overapprox.mat (uncomment line below)
load('../var/mats/ellipsoid_overapprox.mat')

%% Reach-Avoid computation parameters
N = 5;                              % Time horizon for the reach-avoid problem
Dsets = cell(1,N+1);                % Cell of SRA polyhedra (including T)
Dsets{1} = T;                       % D_0(T,K,Eset)
DsetTemp = T;                       % Temporary Dset for the recursion
minusBU = affineMap(U, -B, 'vrep'); % Compute the polyheron for -B U
computeVRep(minusBU);               % Get vertex representation of minusBU
invA = inv(A);                      % A^-1

% 4D plot params
slice_at_vx_vy=[0,0];               % V_x, V_y fixed
axis_vec=[-2,2,-1.5,3];

timer_iter=zeros(1,N+1);
timer_iter(1)=toc(precompute_timer); % Record precomputation time


%% Implemenation of Algorithm 1 for underapproximating reach-avoid
for i = 1:N
    iteration_timer=tic;
    S = DsetTemp - Eset;         % First line of the for loop
    if S.isEmptySet()
        for j=i+1:N+1
            Dsets{j}=Polyhedron([0,0,0,0]);
        end
        fprintf('Reached an empty S at k=%i.\n',i);
        break
    end
    minHRep(S);                         % Miniminizing H before MPT makes us jump to V
    Rtemp=plus(S, minusBU, 'vrep');     % Will return a V-Polytope --- CDDMEX might cause failure 
                                        % here because of the vertex-facet enumeration
    R = affineMap(Rtemp, invA, 'vrep'); % Will return a V-Polytope
    minVRep(R);                         % Miniminizing V before MPT makes us jump to H                  
    DsetTemp = intersect(R, K);         % Will return a H-Polytope --- CDDMEX might cause failure
                                        % here because of the vertex-facet enumeration
    DsetTemp
    Dsets{i+1} = DsetTemp;
    timer_iter(i+1)=toc(iteration_timer);   % Iteration time count
end

%% Display Computational time

fprintf('The computation took %1.2f seconds.\n',sum(timer_iter));

%% Generate Figure 4 Plot
hf = figure(4);
box on;
hold on;
plot(T.slice([3,4], slice_at_vx_vy), 'color', 'k')
plot(K.slice([3,4], slice_at_vx_vy), 'color', 'y')
plot(DsetTemp.slice([3,4], slice_at_vx_vy), 'color', 'g', 'LineStyle', '--')
hold off;

hf.Units = 'inches';
hf.PaperUnits = 'inches';

legend('$\mathcal{T}$','$\mathcal{K}$','$\mathcal{D}_{5}(\mathcal{K},\mathcal{K},\mathcal{E})$');
hf.Children(1).Interpreter = 'latex';

ha = hf.Children(2);
hl = hf.Children(1);
hl.Orientation = 'horizontal';
hl.EdgeColor = [1,1,1];

ha.XLabel.String = '$z_{1}$';
ha.YLabel.String = '$z_{2}$';
ha.XLabel.Interpreter = 'latex';
ha.YLabel.Interpreter = 'latex';

hl.Position = [ha.Position(1), ha.Position(2)+ha.Position(4)+0.02, ha.Position(3), hl.Position(4)];

%% Clean path additions
rmpath('../src')