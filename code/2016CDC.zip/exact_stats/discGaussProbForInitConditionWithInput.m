function meshTransProb = discGaussProbForInitConditionWithInput(x0,mesh,...
                           outerMesh,outerMeshDim,input,stateFun,mu,sigma)
%                       
% function meshTransProb = discGaussProbForInitConditionWithInput(x0,mesh,...
%                           outerMesh,outerMeshDim,input,stateFun,mu,sigma)
%
%   Description:
%   ============
%   Function to compute probability on mesh grid point for a Gaussian
%   random variable. Mean and variance should be compensated to account for
%   system dynamics and input value.
%
%   Inputs:
%   =======
%   x0 - initial condition
%   mesh - n x N vector, n is state dimensions, N is total number of grid
%          points
%   outerMesh - n x N vector, n is state dimensions, N is total number of grid
%               points, "outer" mesh of mesh input (must have equivalent
%               number of state dimensions n)
%   outerMeshDim - Number of dimensions of outerMesh (n)
%   input - input value
%   stateFun - function handle to state dynamics DLTI
%   mu - Gaussian mean (should be shifted by system dynamics and input)
%   sigam - Gaussian variance
%   
%   Output:
%   =======
%   meshTransProb - mesh transition probability, i.e. the likelihood that
%                   a mesh grid point will be reached by Guassian disturbance
%                   when starting from x0
%

% discGaussProb = zeros(size(input,2),size(mesh,1));
mins = [min(mesh(:,1)),min(mesh(:,2))];
maxs = [max(mesh(:,1)),max(mesh(:,2))];
newMu = stateFun(x0,input,mu);
inside = 1;
for i = 1:length(mins)
    if(newMu(i) < mins(i) || newMu(i) > maxs(i))
%         inside = 0;
        break;
    end
end

if(inside)
    newMu = stateFun(x0,input,mu);
    prob = mvncdf(outerMesh,newMu',sigma);
    prob = reshape(prob,outerMeshDim);
    prob = diff(diff(prob,1,2));
    prob = reshape(prob,[],1)';                                            
else
    prob = zeros(1,size(mesh,1));
end
% discGaussProb = zeros(size(input,2),size(mesh,1));

% newMu = stateFun(x0,input,mu);
% prob = mvncdf(outerMesh,newMu',sigma);
% prob = reshape(prob,outerMeshDim);
% prob = diff(diff(prob,1,2));
% prob = reshape(prob,[],1)';
meshTransProb = prob;                                                 
                                                   
end