function discGaussProb = discGaussProbForInitCondition(x0,mesh,outerMesh,outerMeshDim,...
                                                       inputVec,stateFun,mu,sigma)
%
% DEPRECATED/UNUSED
%
discGaussProb = zeros(size(inputVec,2),size(mesh,1));

for j = 1:size(inputVec,1)
    newMu = stateFun(x0,inputVec(j,:)',mu);
    prob = mvncdf(outerMesh,newMu',sigma);
    prob = reshape(prob,outerMeshDim);
    prob = diff(diff(prob,1,2));
    prob = reshape(prob,[],1)';
    discGaussProb(j,:) = prob;
end                                                   
                                                   
end