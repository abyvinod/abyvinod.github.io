function meshDims = getMeshDimensions(mesh)

nCols = size(mesh,2);
tempMesh = mesh;
meshDims = zeros(1,size(mesh,2));
for i = 1:nCols
    for m = 1:nCols
        tempMesh = sortrows(tempMesh,m);
    end
    xVec = zeros(size(tempMesh(:,1)))';
    j = 2;
    xVec(1) = tempMesh(1,1);
    while(j <= length(xVec))
        if(isempty(find(xVec(1:j-1) == tempMesh(j,1),1)))
            xVec(j) = tempMesh(j,1);
            j = j + 1;
        else
            break;
        end
    end
    meshDims(i) = j - 1;
    tempMesh = [tempMesh(:,2:nCols), tempMesh(:,1)];
end

end