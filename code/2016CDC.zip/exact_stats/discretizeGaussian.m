function discGaussProb = discretizeGaussian(outerMesh,mesh,outerMeshDim,inputVector,stateFun,mu,sigma)
%
% DEPRECATED/UNUSED
%
discGaussProb = zeros(size(mesh,1),size(mesh,1),size(inputVector,2));

for j = 1:size(inputVector,1)
    for i = 1:size(mesh,1)
        xVec = mesh(i,:)';
        newMu = stateFun(xVec,inputVector(j,:)',mu);
        prob = mvncdf(outerMesh,newMu',sigma);
        prob = reshape(prob,outerMeshDim);
        prob = diff(diff(prob,1,2));
        prob = reshape(prob,[],1)';
        discGaussProb(i,:,j) = prob;
    end
end


end