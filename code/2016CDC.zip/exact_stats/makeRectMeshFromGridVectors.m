function mesh = makeRectMeshFromGridVectors(gridVectors)
%
% function mesh = makeMeshFromGridVectors(gridVectors)
%
%   Description:
%   ============
%   Function to take n-dimensional grid vectors and return a psudeo mesh.
%   The mesh returned is a concatenation of meshgrid outputs that have
%   reshaped into a single column. It is returned this way because dealing
%   with an n-dimensional matrix in MATLAB would induce migranes.
%
%   Input:
%   ======
%   gridVectors - Cell array of grid vectors
%
%   Output:
%   =======
%   mesh - Concatenation of reshaped meshgrid vectors. There will be as
%          many columns as there were grid vectors. This is my definition
%          for a mesh, the equivalency is,
%               [x1,x2,...,xn] = ndgrid(x1vec,...,xnvec);
%               mesh = [x1(:),...,xn(:)];
%
%   Example:
%   ========
%   mesh = makeMeshFromGridVectors({-2:0.5:2,-2:0.5:2,-2:0.5:2,-2:0.5:2});
%

% Joseph Gleason 29 Feb, 2016

inputArgs = '';
outputArgs = '';
outputMeshGridNames = cell(size(gridVectors));
for i = 1:length(gridVectors)
    varName = sprintf('x%dGrid',i);
    outputMeshGridNames{i} = sprintf('x%dMesh',i);
    eval([varName '= gridVectors{i};']);
    if(i < length(gridVectors))
        inputArgs = [inputArgs varName ','];
        outputArgs = [outputArgs outputMeshGridNames{i} ','];
    else
        inputArgs = [inputArgs varName];
        outputArgs = [outputArgs outputMeshGridNames{i}];
    end
end

eval(['[' outputArgs '] = ndgrid(' inputArgs ');']);

inputArgs = '';
for i = 1:length(gridVectors)
    vecName = sprintf('x%dVec',i);
    eval([vecName '= reshape(' outputMeshGridNames{i} ',[],1);']);
    if(i < length(gridVectors))
        inputArgs = [inputArgs vecName ','];
    else
        inputArgs = [inputArgs vecName];
    end
end

eval(['mesh = [' inputArgs '];']);

end