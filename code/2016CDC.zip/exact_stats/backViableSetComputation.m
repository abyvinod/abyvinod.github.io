function viableSet = backViableSetComputation(t,mesh,outerMesh,outerMeshDim,...
                                                inputVec,stateFun,mu,sigma,NextViableSet)
%
% function viableSet = backViableSetComputation(t,mesh,outerMesh,outerMeshDim,...
%                                                inputVec,stateFun,mu,sigma,NextViableSet)
%
%   Description:
%   ============
%   The function will compute the viable step for the previous time instant
%   for each point in mesh for linear systems with Gaussian perturbations.
%
%   Inputs:
%   ======
%   t - Time value
%   mesh - Mesh variable for which the probabilities and control policies
%          will be determined.
%   outerMesh - External mesh that encompasses the mesh input. This mesh is
%               used for discretizing the Gaussian probabilities.
%   outerMeshDims - Number of points in each dimension for the outerMesh.
%   inputVec - Vector of inputs, really more mesh of inputs.
%   stateFun - State dynamics function (discrete time).
%   mu - Additive Gaussian disturbance mean.
%   sigma - Additive Gaussian disturbance variance.
%   NextViableSet - A ViableSet object for the next time step.
%
%   Outputs:
%   ========
%   viableSet - A ViableSet object for the current time.
%
%   Example:
%   ========
%   See doubleIntTest.
%

% Joseph Gleason - 2 March, 2016

% Initialize mesh viability and optimal policy variables
meshViab = zeros(size(mesh,1),1);
optPolicy = cell(size(mesh,1),1);

% Loop over mesh and compute maximum likelihood and optimal control
for i = 1:size(mesh,1)
    [maxProb,input] = optViabPolicyForInitCond(mesh(i,:),mesh,outerMesh,outerMeshDim,...
                                               inputVec,stateFun,mu,sigma,NextViableSet.meshViab);
    optPolicy{i} = [NextViableSet.meshPolicy{i};input];
    meshViab(i) = maxProb;
end

% Create new viable set
viableSet = KnownViableSet(t,mesh,meshViab,optPolicy);

end