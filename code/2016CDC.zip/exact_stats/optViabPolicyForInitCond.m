function [maxProb,input] = optViabPolicyForInitCond(x0,mesh,outerMesh,outerMeshDim,...
                                                     inputVec,stateFun,mu,sigma,nextStepViabProb)
%                                                 
% function [maxProb,input] = optViabPolicyForInitCond(x0,mesh,outerMesh,outerMeshDim,...
%                                                     inputVec,stateFun,mu,sigma,nextStepViabProb)
%
%   Description:
%   ============
%   A function to determine the maximum likelihood and optimal input for a
%   point in a set to remain viable.
%
%   Inputs:
%   =======
%   x0 - Initial condition (point for which computation is being done).
%   mesh - Mesh variable for which the probability and input is computed.
%   outerMesh - External mesh that encompasses the mesh input. This mesh is
%               used for discretizing the Gaussian probabilities.
%   outerMeshDims - Number of points in each dimension for the outerMesh.
%   inputVec - Vector of inputs, really more mesh of inputs.
%   stateFun - State dynamics function (discrete time).
%   mu - Additive Gaussian disturbance mean.
%   sigma - Additive Gaussian disturbance variance.
%   nextStepViabProb - Vector of probabilities for subsequent steps to
%   remain viable.
%   
%   Outputs:
%   ========
%   maxProb - Maximum probability of remaining viable for given x0.
%   input - Value in inputVec which achieves the maximum probabiliyt.
%



viabProb = zeros(size(inputVec,1),1);
for i = 1:length(inputVec)
    % Some code will go here eventually to deal with
    % uncertain/nonstationary noise. Recomputing the variance matrix is
    % needed.
    meshProb = discGaussProbForInitConditionWithInput(x0',mesh,outerMesh,outerMeshDim,...
                                                       inputVec(i),stateFun,mu,sigma);
    viabProb(i) = meshProb * nextStepViabProb;
end

maxProb = max(viabProb);
input = inputVec(find(viabProb == maxProb,1),:);

end