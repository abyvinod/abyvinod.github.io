% doubleIntTest
%
%   Description:
%   ============
%   Test script for viable set computation code. The system modeled is a
%   discretized version of the continuous time double integrator:
%       \dot{x} = [0 1; 0 0] * x + [0; 1] * u
%   Additive Gaussian noise preturbs the problem to make this a stochastic
%   viability problem.
%
%   Script will close all figures and clear all variables currently in
%   memory.
%

close all
clearvars

% Parameters, etc.
T = 0.25;          % discretization time-step
endTime = 1;      % end time (or start for backwards computing)
nT = int16(endTime / T) + 1; % number of time steps

cd unk_var

% x1 and x2 outer vectors
x1OuterVec = -1:0.05:1;
x2OuterVec = -1:0.05:1;

% input vectors
inputMesh = UniformRectMesh.makeRectMeshFromGridVectors([-0.1:0.05:0.1]);
% u = -0.1:0.1:0.1;

% state dynamics function
stateFun = @(x,u,w) [1,T;0,1] * x + [T^2 / 2; T] * u + w;

% making meshes
outerMesh = UniformRectMesh.makeRectMeshFromGridVectors(x1OuterVec,x2OuterVec);
mesh = outerRectMeshToInnerRectMesh(outerMesh);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Viable Set applromixation Computation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic

% Viable Set computations
% Initialize Viable Set Cell Array
ApproxViableSets = cell(1,nT);

%Initial Viable Set
ApproxViableSets{1} = ViableSet(mesh,endTime,ones(size(mesh.gridPoints,1),1));
timeVec = linspace(endTime,0,nT);

% Base mean and variance
sigma = 0.05*eye(2);
mu = [0,0]';

% Viable set computation loop
for i = 2:nT
    time = timeVec(i);
    fprintf('Computing Approx Viable Set for t = %f', time)
    viableSetStart = tic;
    ApproxViableSets{i} = backViableSetComputation(time,mesh,outerMesh,inputMesh,stateFun,mu,sigma,ApproxViableSets{i-1});
    viableSetCompTime = toc(viableSetStart);
    fprintf('    DONE! Computation time: %f\n',viableSetCompTime);
end

toc

% % Some final plotting codes.
x1 = reshape(mesh.gridPoints(:,1),mesh.pointsPerDim);
x2 = reshape(mesh.gridPoints(:,2),mesh.pointsPerDim);
figure;
subplot(1,2,1)
contourf(x1,x2,reshape(ApproxViableSets{3}.viability,mesh.pointsPerDim));
plotAxes.Title.String = sprintf('Time: %f',ApproxViableSets{3}.time);
colorbar;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Known Variance Viable Set Compuatation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd ../exact_stats

outerMesh = makeRectMeshFromGridVectors({x1OuterVec,x2OuterVec});
outerMeshDim = [length(x1OuterVec),length(x2OuterVec)];
mesh = outerRectMeshToInnerRectMesh(outerMesh);
meshDims = KnownViableSet.getMeshDimensions(mesh);

u = -0.1:0.1:0.1;

tic
% Viable Set computations
% Initialize Viable Set Cell Array
KnownViableSets = cell(1,nT + 1);

%Initial Viable Set
KnownViableSets{1} = KnownViableSet(endTime,mesh,ones(size(mesh,1),1));
timeVec = linspace(endTime,0,nT);

% Base mean and variance
sigma = 0.03*eye(2);
mu = [0,0]';

% Viable set computation loop
for i = 2:nT
    time = timeVec(i);
    fprintf('Computing Known Viable Set for t = %f', time)
    knownStart = tic;
    KnownViableSets{i} = backViableSetComputation(time,mesh,outerMesh,outerMeshDim,u',...
                                             stateFun,mu,sigma,KnownViableSets{i-1});
    knownViableTime = toc(knownStart);
    fprintf('    DONE! Computation time: %f\n',knownViableTime);
end

toc

x1 = reshape(mesh(:,1),meshDims);
x2 = reshape(mesh(:,2),meshDims);
subplot(1,2,2)
contourf(x1,x2,reshape(KnownViableSets{3}.meshViab,meshDims));
plotAxes.Title.String = sprintf('Time: %f',KnownViableSets{3}.time);
colorbar

cd ..