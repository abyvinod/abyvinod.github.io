function rectMesh = makeRectMeshFromGridVectors(varargin)
%
% function mesh = makeMeshFromGridVectors(varargin)
%
%   Description:
%   ============
%   Function to take n-dimensional grid vectors and return a psudeo mesh.
%   The mesh returned is a concatenation of meshgrid outputs that have
%   reshaped into a single column. It is returned this way because dealing
%   with an n-dimensional matrix in MATLAB would induce migranes.
%
%   Input:
%   ======
%   varargin - Cell array of grid vectors (MATLAB's variable number of
%               arguments name)
%
%   Output:
%   =======
%   mesh - Concatenation of reshaped meshgrid vectors. There will be as
%          many columns as there were grid vectors. This is my definition
%          for a mesh, the equivalency is,
%               [x1,x2,...,xn] = ndgrid(x1vec,...,xnvec);
%               mesh = [x1(:),...,xn(:)];
%
%   Example:
%   ========
%   mesh = makeMeshFromGridVectors({-2:0.5:2,-2:0.5:2,-2:0.5:2,-2:0.5:2});
%

% Joseph Gleason 29 Feb, 2016

inputArgs = '';
outputArgs = '';
outputGridNames = cell(size(varargin));
spacing = zeros(size(varargin));
for i = 1:length(varargin)
    spacing(i) = varargin{i}(2) - varargin{i}(1);
    varName = sprintf('x%dVec',i);
    outputGridNames{i} = sprintf('x%dGridPoints',i);
    eval([varName '= varargin{i};']);
    if(i < length(varargin))
        inputArgs = [inputArgs varName ','];
        outputArgs = [outputArgs outputGridNames{i} ','];
    else
        inputArgs = [inputArgs varName];
        outputArgs = [outputArgs outputGridNames{i}];
    end
end

eval(['[' outputArgs '] = ndgrid(' inputArgs ');']);

inputArgs = '';
for i = 1:length(varargin)
    vecName = sprintf('x%dVec',i);
    eval([vecName '= reshape(' outputGridNames{i} ',[],1);']);
    if(i < length(varargin))
        inputArgs = [inputArgs vecName ','];
    else
        inputArgs = [inputArgs vecName];
    end
end

eval(['gridPoints = [' inputArgs '];']);

rectMesh = UniformRectMesh(gridPoints,spacing);

end