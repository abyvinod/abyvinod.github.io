classdef UniformRectMesh < UniformMesh
    properties (SetAccess = private)
        mins
        maxs
        pointsPerDim
    end
    methods 
        function obj = UniformRectMesh(gridPoints,spacing)
            obj@UniformMesh(gridPoints,spacing);
            obj.mins = UniformRectMesh.getMinsFromPoints(gridPoints);
            obj.maxs = UniformRectMesh.getMaxsFromPoints(gridPoints);
            
            pointsPerDimen = zeros(size(obj.mins));
            for i = 1:length(obj.mins)
                pointsPerDimen(i) = int16((obj.maxs(i) - obj.mins(i)) / spacing(i) + 1);
            end
            obj.pointsPerDim = pointsPerDimen;
        end
        [meshDims] = getRectMeshDims(obj);
    end
    
    methods (Static)
        [mins] = getMinsFromPoints(gridPoints);
        [maxs] = getMaxsFromPoints(gridPoints);
        [rectMesh] = makeRectMeshFromGridVectors(varargin);
    end
end