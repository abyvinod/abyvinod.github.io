function maxs = getMaxsFromPoints(gridPoints)

maxs = zeros(1,size(gridPoints,2));
for i = 1:size(gridPoints,2)
    maxs(i) = max(gridPoints(:,i));
end

end