function mins = getMinsFromPoints(gridPoints)

mins = zeros(1,size(gridPoints,2));
for i = 1:size(gridPoints,2)
    mins(i) = min(gridPoints(:,i));
end

end