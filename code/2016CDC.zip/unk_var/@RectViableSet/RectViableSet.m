classdef RectViableSet < UniformRectMesh
%
% class ViableSet
%
%   Description:
%   ============
%   A class to store usefull information about a viable set.
%
    properties (SetAccess = private)
        time
        viability
        policy
    end
    
    methods
        function obj = RectViableSet(mesh,t,viabProb,contPolicy)
            obj@UniformRectMesh(mesh.gridPoints,mesh.spacing);
            obj.time = t;
            if(nargin < 4)
                obj.viability = viabProb;
            else
                obj.viability = viabProb;
                obj.policy = contPolicy;
            end
        end
    end
    
    methods (Static)
        [meshDims] = getRectMeshDimensions(mesh);
    end
end