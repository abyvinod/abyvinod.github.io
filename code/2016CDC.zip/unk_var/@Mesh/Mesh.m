classdef Mesh
    properties
        nDims
        gridPoints
    end
    
    methods
        function obj = Mesh(gridPoints)
            obj.gridPoints = gridPoints;
            obj.nDims = size(gridPoints,2);
        end
    end
end
