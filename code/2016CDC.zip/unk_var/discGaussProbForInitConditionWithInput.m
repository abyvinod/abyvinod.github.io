function meshTransProb = discGaussProbForInitConditionWithInput(mesh,outerMesh,mu,sigma)
%                       
% function meshTransProb = discGaussProbForInitConditionWithInput(mesh,outerMesh,mu,sigma)
%
%   Description:
%   ============
%   Function to compute probability on mesh grid point for a Gaussian
%   random variable. Mean and variance should be compensated to account for
%   system dynamics and input value.
%
%   Inputs:
%   =======
%   mesh - UniformRectMesh object
%   outerMesh - UniformRectMesh object that acts as the "outer" mesh for
%               the mesh object
%   mu - Gaussian mean (should be shifted by system dynamics and input)
%   sigam - Gaussian variance
%   
%   Output:
%   =======
%   meshTransProb - mesh transition probability, i.e. the likelihood that
%                   a mesh grid point will be reached by Guassian disturbance
%
%   Comments:
%   =========
%   Joseph Gleason - 02-21-2017 --- All of the initial conditioning, input
%   handling, and mean/variance determination shoudl be done prior to using
%   this function. E.g. if x0 is a known point and the system is perturbed
%   by DLTI dynamics x_1 = Ax0 + Bu + w then if w~N(a,sigma) then
%   x_1~N(a+Ax0+Bu, sigma). The likelihood that x_1 will reach a point on
%   the mesh can be computed using this function with mu=a+Ax0+Bu and 
%   sigma=sigma.

% discGaussProb = zeros(size(input,2),size(mesh,1));

if(isa(mesh,'UniformRectMesh'))
    prob = mvncdf(outerMesh.gridPoints,mu',sigma);
    prob = reshape(prob,outerMesh.pointsPerDim);
    prob = diff(diff(prob,1,2));
    prob = reshape(prob,[],1)';         
    meshTransProb = prob;  
else
    % some other code for non-rectangular meshes
end
    
end