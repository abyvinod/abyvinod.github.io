function innerMesh = outerRectMeshToInnerRectMesh(outerMesh)
%
% function innerMesh = outerRectMeshToInnerRectMesh(outerMesh)
%
%   Description:
%   ============
%   Function to convert an "outer" rectangular mesh into an interior
%   rectangular mesh
%
%   Inputs:
%   =======
%   outerMesh - UniformRectMesh object
%   
%   Outputs:
%   ========
%   innerMesh - UniformRectMesh object
%
%   Comments:
%   =========
%   Joseph Gleason - 02/21/2017 --- the utility of this is important when
%   computing Gaussian likelihoods later. The point is to define a gridded
%   unifrom rectangular mesh that will provide bounderies for approximation
%   of Gaussian transition probabilities. The follows ASCII schematic shows
%   a 2-D representation of what the code does: x's are the outer mesh, o's
%   are the internal mesh
%       x---x---x---x---x---x---x...
%       | o | o | o | o | o | o |...
%       x---x---x---x---x---x---x...
%       | o | o | o | o | o | o |...
%       x---x---x---x---x---x---x...
%       | o | o | o | o | o | o |...
%       x---x---x---x---x---x---x...
%       .   .   .   .   .   .   .
%       .   .   .   .   .   .   .
%       .   .   .   .   .   .   .

nCols = size(outerMesh.gridPoints,2);
gridVectors = cell(1,size(outerMesh.gridPoints,2));
tempGridPoints = outerMesh.gridPoints;
for i = 1:nCols
    for m = 1:nCols
        tempGridPoints = sortrows(tempGridPoints,m);
    end
    xVec = zeros(size(tempGridPoints(:,1)))';
    j = 2;
    xVec(1) = tempGridPoints(1,1);
    while(j <= length(xVec))
        if(isempty(find(xVec(1:j-1) == tempGridPoints(j,1),1)))
            xVec(j) = tempGridPoints(j,1);
            j = j + 1;
        else
            break;
        end
    end
    xVec = xVec(1:j - 1);
    xVec = xVec(1:j - 2) + diff(xVec)/2;
    gridVectors{i} = xVec;
    tempGridPoints = [tempGridPoints(:,2:nCols), tempGridPoints(:,1)];
end

innerMesh = UniformRectMesh.makeRectMeshFromGridVectors(gridVectors{:});

end
