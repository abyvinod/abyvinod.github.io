classdef ViableSet < Mesh
%
% class ViableSet
%
%   Description:
%   ============
%   A class to store usefull information about a viable set.
%
    properties (SetAccess = private)
        time
        viability
        policy
    end
    
    methods
        function obj = ViableSet(mesh,t,viabProb,contPolicy)
            obj@Mesh(mesh.gridPoints);
            obj.time = t;
            if(nargin < 4)
                obj.viability = viabProb;
                obj.policy = cell(1,size(obj.gridPoints(:,1),1));
            else
                obj.viability = viabProb;
                obj.policy = contPolicy;
            end
        end
    end
    
    methods (Static)
        [meshDims] = getRectMeshDimensions(mesh);
    end
end