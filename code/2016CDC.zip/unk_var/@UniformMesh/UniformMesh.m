classdef UniformMesh < Mesh
    properties (SetAccess = private)
        spacing
    end
    methods 
        function obj = UniformMesh(gridPoints,spacing)
            obj@Mesh(gridPoints);
            obj.spacing = spacing;
        end
        [rectMesh] = myUniformSuperRectMesh(obj);
    end
end