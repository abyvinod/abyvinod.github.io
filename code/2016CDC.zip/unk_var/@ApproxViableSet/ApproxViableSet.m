classdef ApproxViableSet < ViableSet
%
% class ViableSet
%
%   Description:
%   ============
%   A class to store usefull information about a viable set.
%
    properties (SetAccess = private)
        transformMat
    end
    
    methods
        function obj = ApproxViableSet(time,mesh,meshViab,transformMat,...
                                        meshPolicy,meshDims)
            if(nargin < 5)
                superClassArgs = {time,mesh,meshViab};
            elseif(nargin < 6)
                superClassArgs = {time,mesh,meshViab,meshPolicy};
            else
                superClassArgs = {time,mesh,meshViab,meshPolicy,meshDims};
            end
            obj@ViableSet(superClassArgs{:});
            obj.transformMat = transformMat;
        end
    end
    
    methods (Static)
        [meshDims] = getMeshDimensions(mesh);
    end
end