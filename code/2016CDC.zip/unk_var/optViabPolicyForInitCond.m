function [maxProb,input] = optViabPolicyForInitCond(x0,mesh,outerMesh,...
                                                     inputMesh,stateFun,mu,sigma,nextStepViabProb)
%                                                 
% function [maxProb,input] = optViabPolicyForInitCond(x0,mesh,outerMesh,outerMeshDim,...
%                                                     inputVec,stateFun,mu,sigma,nextStepViabProb)
%
%   Description:
%   ============
%   A function to determine the maximum likelihood and optimal input for a
%   point in a set to remain viable.
%
%   Inputs:
%   =======
%   x0 - Initial condition (point for which computation is being done).
%   mesh - Mesh variable for which the probability and input is computed.
%   outerMesh - External mesh that encompasses the mesh input. This mesh is
%               used for discretizing the Gaussian probabilities.
%   outerMeshDims - Number of points in each dimension for the outerMesh.
%   inputVec - Vector of inputs, really more mesh of inputs.
%   stateFun - State dynamics function (discrete time).
%   mu - Additive Gaussian disturbance mean.
%   sigma - Additive Gaussian disturbance variance.
%   nextStepViabProb - Vector of probabilities for subsequent steps to
%   remain viable.
%   
%   Outputs:
%   ========
%   maxProb - Maximum probability of remaining viable for given x0.
%   input - Value in inputVec which achieves the maximum probabiliyt.
%

% fid = fopen('templogfile.txt','w');

if(isa(mesh,'UniformRectMesh'))
    viabProb = zeros(size(inputMesh.gridPoints,1),1);
    for i = 1:size(inputMesh.gridPoints,1)
        % Determine whether the expected value of the state is in the
        % viable set, if not the probability is set to zero.
        mins = mesh.mins;
        maxs = mesh.maxs;
        newMu = stateFun(x0',inputMesh.gridPoints(i,:)',mu);
        inside = 1;
        for j = 1:length(mins)
            if(newMu(j) < mins(j) || newMu(j) > maxs(j))
                inside = 0;
                break;
            end
        end
        if(inside)
            % For a uniform rectangular mesh, the transition matrix
            % required for underapproximation is always the identity.
            meshProb = discGaussProbForInitConditionWithInput(mesh,outerMesh,newMu,sigma);                                          
        else
            meshProb = zeros(1,size(mesh.gridPoints,1));
        end

        viabProb(i) = meshProb * nextStepViabProb;
    end

    maxProb = max(viabProb);
    input = inputMesh.gridPoints(find(viabProb == maxProb,1),:);
else
    
end

% fclose(fid);

end