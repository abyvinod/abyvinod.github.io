% doubleIntTest
%
%   Description:
%   ============
%   Test script for viable set computation code. The system modeled is a
%   discretized version of the continuous time double integrator:
%       \dot{x} = [0 1; 0 0] * x + [0; 1] * u
%   Additive Gaussian noise preturbs the problem to make this a stochastic
%   viability problem.
%
%   Script will close all figures and clear all variables currently in
%   memory.
%

% close all
clearvars
tic

% Parameters, etc.
T = 0.25;          % discretization time-step
endTime = 1;      % end time (or start for backwards computing)
nT = int16(endTime / T) + 1; % number of time steps

% x1 and x2 outer vectors
x1OuterVec = -1:0.05:1;
x2OuterVec = -1:0.05:1;

% input vectors
inputMesh = UniformRectMesh.makeRectMeshFromGridVectors([-0.1:0.05:0.1]);
% u = -0.1:0.1:0.1;

% state dynamics function
stateFun = @(x,u,w) [1,T;0,1] * x + [T^2 / 2; T] * u + w;

% making meshes
outerMesh = UniformRectMesh.makeRectMeshFromGridVectors(x1OuterVec,x2OuterVec);
mesh = outerRectMeshToInnerRectMesh(outerMesh);
% outerMesh = makeRectMeshFromGridVectors({x1OuterVec,x2OuterVec});
% outerMeshDim = [length(x1OuterVec),length(x2OuterVec)];
% mesh = outerRectMeshToInnerRectMesh(outerMesh);
% meshDims = ViableSet.getRectMeshDimensions(mesh);

% Viable Set computations
% Initialize Viable Set Cell Array
ViableSets = cell(1,nT);

%Initial Viable Set
ViableSets{1} = ViableSet(mesh,endTime,ones(size(mesh.gridPoints,1),1));
timeVec = linspace(endTime,0,nT);

% Base mean and variance
sigma = 0.05*eye(2);
mu = [0,0]';

% Viable set computation loop
for i = 2:nT
    time = timeVec(i);
    fprintf('Computing Viable Set for t = %f', time)
    viableSetStart = tic;
    ViableSets{i} = backViableSetComputation(time,mesh,outerMesh,inputMesh,stateFun,mu,sigma,ViableSets{i-1});
    viableSetCompTime = toc(viableSetStart);
    fprintf('    DONE! Computation time: %f\n',viableSetCompTime);
end

toc

% Some final plotting codes.
x1 = reshape(mesh.gridPoints(:,1),mesh.pointsPerDim);
x2 = reshape(mesh.gridPoints(:,2),mesh.pointsPerDim);
figure;
j = 1;
for i = 2:floor(nT/4):nT
    plotAxes = subplot(1,4,j);
        contourf(x1,x2,reshape(ViableSets{i}.viability,mesh.pointsPerDim));
%         plotAxes.View = [0 90];
        plotAxes.Title.String = sprintf('Time: %f',ViableSets{i}.time);
        colorbar;
    j = j + 1;
end