function discGaussProb = discGaussProbForInitCondition(x0,mesh,outerMesh,outerMeshDim,...
                                                       inputVec,stateFun,mu,sigma)
% 
% function discGaussProb = discGaussProbForInitCondition(x0,mesh,outerMesh,outerMeshDim,...
%                                                        inputVec,stateFun,mu,sigma)
%
%   Description:
%   ============
%   Function to compute with the discretized Gaussian probability for an
%   initial condition.
%
%   Inputs:
%   =======
%   x0 - initial condition
%   mesh - UniformRectMesh object (other mesh object will produce erroneous
%          results.
%   outerMesh - UniformRestMesh object that is the "outer" mesh for the
%               mesh object
%   outerMeshDim - Number of dimensions in the outer mesh (equivalent to
%                  the number of state dimensions)
%   inputVec - input vector
%   stateFun - State dynamics function (discrete-time)
%   mu - Gaussian mean
%   sigam - Gaussian variance
%
%   Outputs:
%   ========
%   discGaussProb - Probability of state perturbed by Gaussian landing "on"
%                   mesh grid point.
%
%   Comments:
%   =========
%   Joseph Gleason - 02-21-2017 --- pretty sure this function is
%   deprecated/not used. See discGaussProbForInitConditionWithInput

discGaussProb = zeros(size(inputVec,2),size(mesh,1));

for j = 1:size(inputVec,1)
    newMu = stateFun(x0,inputVec(j,:)',mu);
    prob = mvncdf(outerMesh,newMu',sigma);
    prob = reshape(prob,outerMeshDim);
    prob = diff(diff(prob,1,2));
    prob = reshape(prob,[],1)';
    discGaussProb(j,:) = prob;
end                                                   
                                                   
end