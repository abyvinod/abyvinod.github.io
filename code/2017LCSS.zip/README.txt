Summary of the codes to do:

Figure 1 is obtained using scriptForChainDI.m (Unmodified version) and Figure1.m. 
    - scriptForChainDI.m will take a lot of time since it computes FTBU for 20 random points for n in [1,40] and also performs DPBDA for n<=3. 
    - Currently set to do patternsearch and fmincon (further compute time reqd). Change the variables on the beginning of the file of reachAvoidChainDI_FT.m to select between fmincon and PS options. useFmincon/usePatternsearch decides the solver to use.
    - Load the matfile curseOfDim_full_10_5_20points_n1to40_reqdOnly.mat and run Figure1.m instead. 
        - The parameters for the experiment are S=[-10,10]^n, T=[-5,5]^n, 20 points per dimension, n\in[1,40], and has the elapsed times and number of testing points only --- information required by Figure1.m.

Figures in Figure 2 are computed by scriptForComparison.m and Figure2.m. 
    - DBPDA and FTBU done over a grid with 1681 points
    - Currently set to do patternsearch and fmincon (further compute time reqd). Change the variables on the beginning of the file of reachAvoidDI_FT.m to select between fmincon and PS options. useFmincon/usePatternsearch decides the solver to use.
    - Load the matfile Figure2_0x05_onX_bothPSandFM.mat and run Figure2.m. 

Table I was generated using scriptForTableI.m. You will have to comment relevant lines from scriptForChainDI (creating a modified version). 
    - A copy of the corresponding MAT-file can be found in Table1_contents.mat.
    - Run the last two lines of the code to get the table values.

Table II was generated using scriptForTableII.m.
    - A copy of the corresponding MAT-file can be found in Table2_contents.mat.
