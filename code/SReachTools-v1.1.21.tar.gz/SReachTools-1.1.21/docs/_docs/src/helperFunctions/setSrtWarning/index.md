---
layout: docs
title: setSrtWarning.m
---

```
setSrtWarning is a function.
    setSrtWarning(warn_str, state)
```
