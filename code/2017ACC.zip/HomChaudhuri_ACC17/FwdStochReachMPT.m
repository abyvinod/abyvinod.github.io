%% Reach Computation
currTime=1;
ReachTube=InitSet;
RSprev=InitSet;
GridPoints=cell(1,NoOfSteps+1);

gridPointsCount=round(gridDensity*round(InitSet.volume));
gridPointsCount1DPrev=round(gridPointsCount^(1/dim))+1;
gridPointsCountPrev=gridPointsCount1DPrev^dim;
gridPrev=InitSet.grid(gridPointsCount1DPrev);
probPrev=probInitVal*ones(size(gridPrev,1),1);
GridPoints{1,currTime}=[gridPrev,probPrev];      % Init Set Gridding+Probability
gridPrev1D=gridPrev(1:gridPointsCount1DPrev,2);

elapsedTime=zeros(NoOfSteps,1);

% probPrev=griddedInterpolant(gridtemp(:,1), gridtemp(:,2), probprev, 'cubic');
fprintf('No. of steps to evaluate: %2d | GridDensity: %d | Interpn Method: %s\n',NoOfSteps,gridDensity,interpnMethod);
while currTime<=NoOfSteps
    timerVal=tic;    
    fprintf('Evaluating for step number: %2d',currTime);
    RS=system.reachableSet('X',RSprev)+DisturbSet;
    ReachTube=[ReachTube,RS];
    
    gridPointsCount=round(gridDensity*round(RS.volume));
    gridPointsCount1D=round(gridPointsCount^(1/dim))+1;
    gridCurr=RS.grid(gridPointsCount1D);
    
    gridPointsCount=gridPointsCount1D^dim;
    probCurr=zeros(gridPointsCount,1);
    probPrevMat=reshape(probPrev,gridPointsCount1DPrev,[]);
    
%     xfirstPrevMat=repmat(gridPrev(1,:),lenDisturbSet,1);    
%     xjumpPrevMat=repmat(gridPrev(2,2)-gridPrev(1,2),lenDisturbSet,2);
    for gridRSIndx=1:gridPointsCount                    % For each grid point
        xplus=gridCurr(gridRSIndx,:);
        xplusvec=repmat(xplus,lenDisturbSet,1);
        xplusMinusw=round((xplusvec-gridDisturbSet)*digitRound)/digitRound;            % This is the x s.t f(x)+w=xplus        
        
        probPrevReqd=interpn(gridPrev1D,gridPrev1D,probPrevMat,xplusMinusw(:,1),xplusMinusw(:,2),interpnMethod,0);
%         if gridRSIndx>=329 && gridRSIndx<=369 && currTime==2
%             containme=RSprev.contains(xplusMinusw');
%             vecdisp=[containme;probPrevReqd';containme-(probPrevReqd>0)']';
%             if sum(vecdisp(:,3))>0
%                 fprintf('\nNo. of violations: %d',sum(vecdisp(:,3)))
%             end
%         end  
%         if currTime==5
%             containme=RSprev.contains(xplusMinusw');
%             vecdisp=[containme;probPrevReqd';containme-(probPrevReqd>0)']';
%             if sum(vecdisp(:,3))>0
%                 fprintf('\nNo. of violations: %d',sum(vecdisp(:,3)))
%             end
%         end  
        probCurr(gridRSIndx)=sum(probDisturbSetVec.*probPrevReqd);
    end
    
    elapsedTime(currTime)=toc(timerVal);%(t));
    timerVal=0;
    fprintf('  %1.3f s\n',elapsedTime(currTime));    
    
    probPrev=probCurr;
    gridPrev=gridCurr;
    gridPrev1D=gridCurr(1:gridPointsCount1D,2);
    gridPointsCount1DPrev=gridPointsCount1D;
    RSprev=RS;        
    
    currTime=currTime+1;        
    GridPoints{1,currTime}=[gridCurr,probCurr];    
end