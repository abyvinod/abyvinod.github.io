%===============================================
% Plot Fig 3
%===============================================
load('Data1.mat')

dd_time = [1 (round(1/dt) + 1) ((round(1.8/dt) + 1)) ((round(2.4/dt) + 1)) steps(end)];

for ii=1:length(dd_time)

    subplot(length(dd_time),1,ii)
    for jj=1:obs.number
            hold on
            h1= DrawRectangle([o_positionx(jj,dd_time(ii)) o_positiony(jj,dd_time(ii)) 1 1 obs.heading(jj)]);
            h1.LineWidth=1; h1.MarkerFaceColor=[0 0 1];
    end


      h3 = plot(robot.Goal(1), robot.Goal(2),'go','linewidth',2); % Goal State
    
    hold on
    h4 = plot(robot.start(1),robot.start(2),'ko','linewidth',2); % starting point
    h2 =  rectangle('Position', [(x_r(dd_time(ii))-0.1) (y_r(dd_time(ii))-0.1) 0.2 0.2],'Edgecolor','r','linewidth',2,'Facecolor',[1 0 0]);  %p5 robot   

    h5 = plot(x_r(1:dd_time(ii)),y_r(1:dd_time(ii)),'r','linewidth',1.5); % p5 robot
    axis([-9 2.5 -4 1])


    ylabel(['t = ' num2str(dt*(dd_time(ii)-1))]);
    box on

    boldify
    
end


%=============================================================
% Min-max robust solution
%=============================================================
load('Data2.mat')

dd_time = [1 (round(1/dt) + 1) ((round(1.8/dt) + 1)) ((round(1.8/dt) + 1)) ((round(1.8/dt) + 1))];
cc = hsv(100);

for ii=1:length(dd_time)

   subplot(length(dd_time),1,ii)
    
    hold on

    h6=  plot(x_r(dd_time(ii)), y_r(dd_time(ii)),'o','color',cc(60,:)); % p0 robot Circular
    set(h6(1),'MarkerEdgeColor',cc(60,:),'MarkerFaceColor',cc(60,:))


    h5 = plot(x_r(1:dd_time(ii)),y_r(1:dd_time(ii)),'color',cc(60,:),'linewidth',1.2); % p0 robot
     h3 = plot(robot.Goal(1), robot.Goal(2),'go','linewidth',2); % New Goal State
    
    hold on
    h4 = plot(robot.start(1),robot.start(2),'ko','linewidth',2); % starting point
    box on

    boldify
     axis([-9 2.5 -4 1])
end
legend([h3,h4],'Goal','Start')