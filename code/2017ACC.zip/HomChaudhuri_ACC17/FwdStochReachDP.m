%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham
% Purpose of the program: Fwd Stochastic Reach computation for a point mass
% using Dynamic Programming and reversibility
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clear
% clc

%% Parameters of the program
% NoOfSteps=10;
% gridDensity=100;                    % No. Of grid points per square unit
% InitSetMax=2;             % For NoOfSteps=5,InitSetMax=2, this is what is actually used
% interpnMethod='nearest';
% % InitSetMax=2;
% wmin=1;
% wmax=wmin+1;
% muDisturb=[wmin;wmin]+[0.5;0.5];
% sigmaDisturb=0.1*eye(2);
% Xmax=22;
% wVol=1;                            % Computed by hand

w=linspace(wmin,wmax,round(sqrt(gridDensity*DisturbSetVol))+1);     % No. of points = 5
lw=length(w);
fprintf('Evaluating probDisturbSetMat\n');
probDisturbSetMat=zeros(lw,lw);
for i=1:lw
    for j=1:lw
        probDisturbSetMat(i,j)=mvnpdf([w(i);w(j)],muDisturb,sigmaDisturb);
    end
end
probDisturbSetMat=probDisturbSetMat./sum(sum(probDisturbSetMat));

x=linspace(Xmin,Xmax,round(sqrt(gridDensity*XVol))+1);     % No. of points = 60
lx=length(x);
diffX=x-repmat(InitSetMax,1,lx);
[~,InitSetIndx]=min(abs(diffX));

xprev=zeros(lx,lx,lw,lw,2);
fprintf('Evaluating xplus\n');
for i=1:lx
    for j=1:lx
        for k=1:lw
            for l=1:lw
                xcurr=[x(i);x(j)];
                wcurr=[w(k);w(l)];
                xnext=round((xcurr-wcurr)*digitRound)/digitRound;
                xprev(i,j,k,l,:)=xnext;
            end
        end
    end
end

Vtplus1=zeros(lx,lx);
Vt=zeros(lx,lx);
elapsedTimeDP=zeros(NoOfSteps,1);
Vtplus1(1:InitSetIndx,1:InitSetIndx)=probInitVal;
VDP=zeros(lx,lx,NoOfSteps+1);
VDP(:,:,end)=Vtplus1;
fprintf('No. of steps to evaluate: %2d | GridDensity: %d\n',NoOfSteps,gridDensity);
for currTime=NoOfSteps:-1:1
    fprintf('Evaluating for step number: %2d',currTime);
    timerVal=tic;  
%% For first hitting time
    Vt=zeros(lx,lx);
%     Vt(1:InitSetIndx,1:InitSetIndx)=1;
%% In general
    for i=1:lx
        for j=1:lx
            xprev1=reshape(xprev(i,j,:,:,:),lw,lw,2);            
            Vtemp=interpn(x,x,Vtplus1,xprev1(:,:,1),xprev1(:,:,2),interpnMethod,0);
            Vt(i,j)=sum(sum(probDisturbSetMat.*Vtemp));
        end
    end
    Vtplus1=Vt;
    VDP(:,:,currTime)=Vt;
    elapsedTimeDP(currTime)=toc(timerVal);%(t));
    timerVal=0;
    fprintf('  %1.3f s\n',elapsedTimeDP(currTime));  
end

[xDP,yDP]=meshgrid(x,x);
for currTime=NoOfSteps+1:-1:1
    gridPointsCount1D=sqrt(length(GridPoints{1,currTime}));
    X=reshape(GridPoints{1,currTime}(:,1),gridPointsCount1D,[]);
    Y=reshape(GridPoints{1,currTime}(:,2),gridPointsCount1D,[]);
    prob=reshape(GridPoints{1,currTime}(:,3),gridPointsCount1D,[]);
    probDP=VDP(:,:,NoOfSteps+2-currTime);
    probDR=interpn(X(1,:),Y(:,1),prob,xDP,yDP,interpnMethod,0);
    errPlot=abs(probDP-probDR);
    
%     figure(40+NoOfSteps+1-currTime);
%     clf
%     set(gca,'Fontsize',20);
%     ax1(1)=subplot(3,1,1);
%     surf(x,x,probDP);
%     axis([0 Xmax 0 Xmax]);
%     box on;
%     xlabel('x1');
%     ylabel('x2');
%     zlabel('Stochastic Reachability');
%     title(sprintf('Forward stochastic reachability (FSR) computed using DP-based algorithm at t=%d',currTime));
%     hold on
%     view([90,0])   
%     ax1(2)=subplot(3,1,2);
%     surf(X(1,:),Y(:,1),prob);
%     axis([0 Xmax 0 Xmax]);
%     xlabel('x1');
%     ylabel('x2');
%     zlabel('Stochastic Reachability');
%     title(sprintf('Forward stochastic reachability (FSR) computed using Determ+Recursion algorithm at t=%d',currTime));
%     view([90,0])    
%     box on;
%     ax1(3)=subplot(3,1,3);
%     surf(xDP,yDP,errPlot);
%     hold on
%     xlabel('x1');
%     ylabel('x2');
%     zlabel('Absolute Error');
%     title(sprintf('Absolute error between DP-based and Determ+Recursion algorithm based FSR at t=%d',currTime));
%     axis([0 Xmax 0 Xmax]);
%     view([90,0]) 
%     box on; 
% % %     savefig(sprintf('D:\\Dropbox\\ObstacleAvoidance\\PointMass\\FSR%d',currTime));
% % %     fprintf('%2d:%3.3f,%3.3f\n',currTime,sum(sum(prob)),sum(sum(errPlot))+sum(sum(prob)));
end         

save(workspaceString,'VDP','x','elapsedTimeDP','-append');
% fprintf('Our code is %1.3f times faster.\n',sum(elapsedTimeDP)/sum(elapsedTime));

