These files generate the data and plots for:
  "Computation of forward stochastic reach sets: Application to stochastic, dynamic obstacle avoidance," 
 B. HomChaudhuri, A. P. Vinod, and M. Oishi, 
to appear in Proceedings of the IEEE American Control Conference, 
May 2017.



Matlab version: R2015b.

FwdStochReach.m uses MPT toolbox and calls functions FwdStochReachDP.m, FwdStochReachMPT.m, and FwdStochReachSansMPT.m, to generate Fig. 1(a), 1(b), and 1(c).

fsr_line.m generates the FRS_line.mat. It uses the MPT toolbox, Yalmip, and Matlab's 'conv2' command.It produces the forward stochastic reach set and occupancy function of one rigid body obstacle (square shaped).
obstacle_avoidance.m calls FRS_line.mat and generates Data1 (proposed method:robot avoiding alpha superlevel set) or Data2 (min-max robust solution) according to user input. The code uses 'gurobi' solver paired with matlab and line 5 needs to be modified according to the user. 
fig3.m generates the plot in Fig 3.

