%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham
% Purpose of the program: Fwd Stochastic Reach computation for a point mass
% using the proposed forward SR computation method
% Requires MPT 3.1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
clc
% tic
% close all
%% Parameters of the program
NoOfSteps=10;
Xmin=0;
Xmax=22;
XVol=Xmax^2;
gridDensity=100;                    % No. Of grid points per square unit
digitRound=10^13;
% InitSetMax=12*162/999;             % For NoOfSteps=5,InitSetMax=2, this is what is actually used in FwdStochReachDP.m
InitSetMax=2;
wmin=1;
wmax=wmin+1;
muDisturb=[wmin;wmin]+[0.8;0.8];
sigmaDisturb=0.1*eye(2);
DisturbSet = Polyhedron('lb',[wmin, wmin],'ub',[wmax, wmax]); 
DisturbSetVol=DisturbSet.volume;
interpnMethod='nearest';
%%%%%% System  %%%%%%%
dim = 2;
system = LTISystem('A', [1 0; 0 1]);
% system = LTISystem('A', [1 t; 0 1]);
InitSet=Polyhedron(InitSetMax*[0,0;1,0;0,1;1,1]);
InitSetVol=InitSet.volume;
probInitVal=1/(gridDensity*InitSetVol);
% InitSet=Polyhedron([1,1;2,1;1,2;2,2]+0.001*[0,0;1,0;0,1;1,1]);

%% Derived parameters of the program
lenDisturbSet=round(gridDensity*DisturbSet.volume);
lenDisturbSet1D=round(lenDisturbSet^(1/dim))+1;
gridDisturbSet=DisturbSet.grid(lenDisturbSet1D);
lenDisturbSet=lenDisturbSet1D^dim;

%% Uniform Noise
% probDisturbSet=(1/lenDisturbSet)*ones(round(lenDisturbSet),1);

%% Gaussian Noise
DisturbSet.addFunction(@(x) mvnpdf(x,muDisturb,sigmaDisturb),'f');
probDisturbSetVec=zeros(lenDisturbSet,1);
for gridWIndx=1:lenDisturbSet                            % For each disturbance point
    probDisturbSetVec(gridWIndx)=DisturbSet.feval(gridDisturbSet(gridWIndx,:)');
end
probDisturbSetVec=probDisturbSetVec./sum(probDisturbSetVec);

disp('MPT based recursion');
FwdStochReachMPT

figure(31)
clf
ReachTube.plot('Alpha',0.1)
axis([0 Xmax 0 Xmax]);
box on;
grid on
set(gca,'FontSize',20)
xlabel('x_1')
ylabel('x_2')
title(sprintf('FSReach($\\cdot,\\mathcal{I}$) over time',currTime),'interpreter','latex');
title('')
% savefig('D:\\Dropbox\\ObstacleAvoidance\\PointMass\\DeterministicReachSet');
% print('D:\\Dropbox\\ObstacleAvoidance\\PointMass\\DeterministicReachSet','-dpng');

% figure(32)
% clf
% X=reshape(gridDisturbSet(:,1),lenDisturbSet1D,[]);
% Y=reshape(gridDisturbSet(:,2),lenDisturbSet1D,[]);
% prob=reshape(probDisturbSetVec,lenDisturbSet1D,[]);
% surf(X(1,:),Y(:,1),prob);
% xlabel('w_1');
% ylabel('w_2');
% zlabel('Probability');
% title('Distribution of the disturbance set')
% % savefig('D:\\Dropbox\\ObstacleAvoidance\\PointMass\\DisturbSet');
% % print('D:\\Dropbox\\ObstacleAvoidance\\PointMass\\DisturbSet','-dpng');

formatOut='yyyymmdd-HH_MM_SS';
dateString=datestr(now,formatOut);
% workspaceString=sprintf('C:\Users\bhomchaudhuri\Box Sync\New Mexico\Conference Papers\ACC 2017\ACC code\acccodes\\%s',dateString);
% save(workspaceString,'GridPoints','elapsedTime','gridDensity','InitSet','DisturbSet','elapsedTime');

disp('Dynamic programming based recursion');
FwdStochReachDP

disp('Probability Propagation Fast based recursion');
FwdStochReachSansMPT

% disp('Probability Propagation based recursion');
% FwdStochReachFWD

currTime=1;
gridPointsCount1D=sqrt(length(GridPoints{1,currTime}));
X=reshape(GridPoints{1,currTime}(:,1),gridPointsCount1D,[]);
Y=reshape(GridPoints{1,currTime}(:,2),gridPointsCount1D,[]);
prob=reshape(GridPoints{1,currTime}(:,3),gridPointsCount1D,[]);
probDP=VDP(:,:,NoOfSteps+2-currTime);
probDR=interpn(X(1,:),Y(:,1),prob,xDP,yDP,interpnMethod,0);


figure(33)
clf
set(gca,'Fontsize',20);
hold on
% stem(log(elapsedTimeFWDFast),'m','MarkerSize',10);
stem(elapsedTimeFWDFast,'m','MarkerSize',10,'linewidth',2);
% stem(elapsedTimeFWD,'k','MarkerSize',10)
% stem(elapsedTime,'b','MarkerSize',10)
% stem(log(elapsedTimeDP),'r','MarkerSize',10)
stem(elapsedTimeDP,'r','MarkerSize',10,'linewidth',2)
xlabel('Steps taken from t=0')
ylabel('Time elapsed (seconds)')
% ylabel('Time elapsed (seconds) in log')
% ylabel('$\mathrm{CatchPr}_{\bar{x}_H}(t,\bar{x}_H^\ast[t])$','interpreter','latex');
set(gca,'GridAlpha',0.5)
title('')
xlim([0 NoOfSteps+1])
% title(sprintf('(Fast+Slow) Recursion-based vs MPT-based vs DP-based\nForward Stochastic Reach Set Computation Times'));
% title(sprintf('Probability recursion-based vs DP-based\nForward Stochastic Reach Set Computation Times'));
% title(sprintf('Probability recursion-based vs DP-based Forward Stochastic\nReach Set Computation Times (Semilog plot)'));
% legend(sprintf('PR (Fast) : %3.3f s',sum(elapsedTimeFWDFast)),sprintf('PR : %3.3f s',sum(elapsedTimeFWD)),sprintf('MPT : %3.3f s',sum(elapsedTime)),sprintf('DP : %3.3f s',sum(elapsedTimeDP)),'Location','Best');
% legend(sprintf('PR (Fast) : %3.3f s',sum(elapsedTimeFWDFast)),sprintf('MPT : %3.3f s',sum(elapsedTime)),sprintf('DP : %3.3f s',sum(elapsedTimeDP)),'Location','Best');
% legend(sprintf('PR : %3.3f s',sum(elapsedTimeFWDFast)),sprintf('DP : %3.3f s',sum(elapsedTimeDP)),'Location','Best');
legend(sprintf('Algorithm 1: %3.3f s',sum(elapsedTimeFWDFast)),sprintf('Dynamic Programming: %3.3f s',sum(elapsedTimeDP)),'Location','Best');
grid on
box on
% toc
% savefig('D:\\Dropbox\\ObstacleAvoidance\\PointMass\\ComputationTimes');
% print('D:\\Dropbox\\ObstacleAvoidance\\PointMass\\ComputationTimes','-dpng');