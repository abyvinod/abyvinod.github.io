%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham
% Purpose of the program: Fwd Stochastic Reach computation for a point mass
% using Dynamic Programming and reversibility
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% clear
% clc

% %% Parameters coming from FwdStochReach.m
% NoOfSteps=10;
% gridDensity=100;                    % No. Of grid points per square unit
% interpnMethod='nearest';
% digitRound=10^13;
% 
% %% Disturbance Set parameters
% wmin=1;
% wmax=wmin+1;
% DisturbSetVol=1;                            % Computed by hand
% muDisturb=[wmin;wmin]+[0.5;0.5];
% sigmaDisturb=0.1*eye(2);
% w=linspace(wmin,wmax,round(sqrt(gridDensity*DisturbSetVol))+1);     % No. of points = 5
% lw=length(w);
% [xDisturbSet,yDisturbSet]=meshgrid(w,w);
% lenDisturbSet=lw*lw;
% DisturbSetGrid=reshape([xDisturbSet,yDisturbSet],lenDisturbSet,2);
% fprintf('Evaluating probDisturbSetMat\n');
% probDisturbSetMat=zeros(lw,lw);
% for i=1:lw
%     for j=1:lw
%         probDisturbSetMat(i,j)=mvnpdf([w(i);w(j)],muDisturb,sigmaDisturb);
%     end
% end
% probDisturbSetMat=probDisturbSetMat./sum(sum(probDisturbSetMat));
probDisturbSetVec=reshape(probDisturbSetMat,lw*lw,1);

%% Gridding the state-space
Xmin=0;
Xmax=22;
XVol=Xmax*Xmax;
x=linspace(Xmin,Xmax,round(sqrt(gridDensity*XVol))+1);     % No. of points = 60
lx=length(x);
xfirst=[x(1),x(1)];
xinc=x(2)-x(1);

%% Init Set initialization (Rprev has the indices in the universal grid which make up the InitSet)
InitSetMax=2;
diffX=x-repmat(InitSetMax,1,lx);
[~,InitSetIndx]=min(abs(diffX));
InitSetGrid1D=1:InitSetIndx;
lenInitSetGrid1D=length(InitSetGrid1D);
[xInitSet,yInitSet]=meshgrid(InitSetGrid1D,InitSetGrid1D);
lenRprev=lenInitSetGrid1D*lenInitSetGrid1D;
Rprev=reshape([xInitSet,yInitSet],lenRprev,2);
Pprev=zeros(lx,lx);
Pprev(1:InitSetIndx,1:InitSetIndx)=probInitVal;
%% Forward Stochastic Reach Set Collection
FSR={};
FSR{1,1}=Rprev;
FSR{1,2}=Pprev;

%% Dynamics computation
xplusFWDFast=zeros(lx,lx,lw,lw,2);
fprintf('Evaluating xplus\n');
% for i=1:lx
%     for j=1:lx
%         xcurr=[x(i),x(j)];
%         xnextVec=repmat(xcurr,lenDisturbSet,1)+DisturbSetGrid;
%         xnextRounded=round(xnextVec.*digitRound)./digitRound;        
%         xnextIndx=round((xnextRounded-repmat(xfirst,lenDisturbSet,1))./xinc)+ones(lenDisturbSet,2);
%         xplusFWDFast(i,j,:,:,:)=reshape(xnextIndx,lw,lw,2);        
%     end
% end
for i=1:lx
    for j=1:lx
        for k=1:lw
            for l=1:lw
                xcurr=[x(i);x(j)];
                wcurr=[w(k);w(l)];
                xnext=round((xcurr+wcurr)*digitRound)/digitRound;
                xnextIndx=round((xnext-Xmin)./xinc)+1;
                xplusFWDFast(i,j,k,l,:)=xnextIndx;
            end
        end
    end
end
% for i=1:lx
%     for j=1:lx
%         xcurr=[x(i),x(j)];
%         xnextVec=repmat(xcurr,lenDisturbSet,1)+DisturbSetGrid;
%         xnextRounded=round(xnextVec.*digitRound)./digitRound;        
%         xplusFWDFast(i,j,:,:,:)=reshape(xnextRounded,lw,lw,2);        
%     end
% end


elapsedTimeFWDFast=zeros(NoOfSteps,1);
fprintf('No. of steps to evaluate: %2d | GridDensity: %d\n',NoOfSteps,gridDensity);
for currTime=2:NoOfSteps+1
    fprintf('Evaluating for step number: %2d',currTime);
    timerVal=tic;  
    
    Pcurr=zeros(lx,lx);
    RcurrFlag=zeros(lx,lx);
    Rcurr=[];
    %% In general
    for i=1:lenRprev        
        xcurrIndx=Rprev(i,:);
        probx=Pprev(xcurrIndx(1),xcurrIndx(2));
        xplusForij=reshape(xplusFWDFast(xcurrIndx(1),xcurrIndx(2),:,:,:),lw*lw,2);            
        PcurrIndx=sub2ind([lx,lx],xplusForij(:,1),xplusForij(:,2));
        Pcurr(PcurrIndx)=Pcurr(PcurrIndx)+probDisturbSetVec.*probx;        
        RcurrFlag(PcurrIndx)=1;                
    end
    [Rcurr(:,1),Rcurr(:,2)]=find(RcurrFlag==1);
    FSR{currTime,1}=Rcurr;
    FSR{currTime,2}=Pcurr;
    Pprev=Pcurr;
    Rprev=Rcurr;
    lenRprev=length(Rprev);        
    
    elapsedTimeFWDFast(currTime-1)=toc(timerVal);%(t));
    timerVal=0;
    fprintf('  %1.3f s\n',elapsedTimeFWDFast(currTime-1));  
end

[xDP,yDP]=meshgrid(x,x);
for currTime=1:NoOfSteps+1
    gridPointsCount1D=sqrt(length(GridPoints{1,currTime}));
    X=reshape(GridPoints{1,currTime}(:,1),gridPointsCount1D,[]);
    Y=reshape(GridPoints{1,currTime}(:,2),gridPointsCount1D,[]);
    prob=reshape(GridPoints{1,currTime}(:,3),gridPointsCount1D,[]);
    probFWDFast=FSR{currTime,2};
%     errPlot=interpn(x,x,probDP,X,Y,interpnMethod)-prob;
    probDR=interpn(X(1,:),Y(:,1),prob,xDP,yDP,interpnMethod);
    probDR(isnan(probDR))=0;
    errPlot=abs(probFWDFast-probDR);
    
%     figure(80+currTime);
%     clf
%     set(gca,'Fontsize',20);
%     ax1(1)=subplot(3,1,1);
%     surf(x,x,probFWDFast);
%     axis([0 Xmax 0 Xmax]);
%     box on;
%     xlabel('x1');
%     ylabel('x2');
%     zlabel('Stochastic Reachability');
%     title(sprintf('Forward stochastic reachability (FSR) computed using Fast Probability-Propagation algorithm at t=%d',currTime));
%     hold on
%     view([90,0])   
%     ax1(2)=subplot(3,1,2);
%     surf(X(1,:),Y(:,1),prob);
%     axis([0 Xmax 0 Xmax]);
%     xlabel('x1');
%     ylabel('x2');
%     zlabel('Stochastic Reachability');
%     title(sprintf('Forward stochastic reachability (FSR) computed using Determ+Recursion algorithm at t=%d',currTime));
%     view([90,0])    
%     box on;
%     ax1(3)=subplot(3,1,3);
% %     surf(X,Y,errPlot);
%     surf(xDP,yDP,errPlot);
%     hold on
%     xlabel('x1');
%     ylabel('x2');
%     zlabel('Absolute Error');
%     title(sprintf('Absolute Error between Fast Probability-Propagation and Determ+Recursion algorithm based FSR at t=%d',currTime));
%     axis([0 Xmax 0 Xmax]);
%     view([90,0]) 
%     box on; 
% % %     savefig(sprintf('D:\\Dropbox\\ObstacleAvoidance\\PointMass\\FSR%d_PPFast',currTime));
% % %     fprintf('%2d:%3.3f,%3.3f\n',currTime,sum(sum(prob)),sum(sum(errPlot))+sum(sum(prob)));
end  
figure(1)
    set(gca,'Fontsize',20);
%     ax1(1)=subplot(3,1,1);
    a = find(probFWDFast==0);
    probFWDFast(a) = nan;
    surf(x,x,probFWDFast,'edgecolor','none');
    axis([0 Xmax 0 Xmax 0 2e-3 ]); 
%     axis([0 Xmax 0 Xmax]);
    box on;
    xlabel('x1');
    ylabel('x2');
     zlabel('\psi_x(\cdot;10)');
%     zlabel('Stochastic Reachability');
%     title(sprintf('Forward stochastic reachability (FSR) computed using Fast Probability-Propagation algorithm at t=%d',currTime));
save(workspaceString,'FSR','x','elapsedTimeFWDFast','-append');