clear
clc
prompt = 'Which problem to be solved(choose 1 or 2): 1 proposed method; 2 for min-max robust solution \n';
Problem = input(prompt);
addpath('C:\gurobi652\win64\matlab\')

% tic
load('FSR_line.mat')

xmin = -12;xmax = 12;ymin = -12;ymax = 12;
dx = xvec(2)-xvec(1);dy=yvec(2)-yvec(1);
obs.heading = [0 20 180 90]*pi/180;
  
obs.linearSpeedRange = values;
obs.linearSpeedProb = prob; 
xv = xmin:dx:xmax;yv = ymin:dx:ymax;

obs.initial = [-6 -0.5;-6.5 -2;2 -2.2];
obs.number = size(obs.initial,1);
obs.sizex = 0.5; obs.sizey = 0.5;
robot.maxvelocity_x=1;robot.minvelocity_x= -0.2;%robot.minvelocity= -0.6;
robot.maxvelocity_y=1;robot.minvelocity_y= 0.1;

robot.Goal = [-4.5 0.5];

robot.start = [-5 -2.5];
numberofSidesObstacle = 4;


dt = 0.2;
obs.pos = obs.initial;
robot.pos(1,:) =robot.start;
robot.dt = dt; robot.dx=dx;robot.dy=dy;
flag=0;
steps=1;

for i=1:obs.number
    o_locations(i,1,1) = obs.pos(i,1); o_locations(i,2,1) = obs.pos(i,2);
end


if Problem ==1
    p_th = 0.015;%0.01
    T = 5; %sec
elseif Problem ==2
    T=5; % secs
    p_th = 0;
else
    msg = 'Please choose between 1 and 2';
    error(msg)
end
M = T/dt;
robot.xlimit = [xmin xmax];robot.ylimit = [ymin ymax];
t=0;
nx = 2; nu =2;
x0 = robot.start';
M_big = 1e5;
x_r(1) = robot.pos(1,1); y_r(1) = robot.pos(1,2);

failure = 0; 
% seed = rng;
load('seed.mat')
rng(seed);
while flag==0

    yalmip('clear');
    constraints = []; objective = 0;
     As = zeros(nx); Bs = eye(nu); % point mass robot
     r_sys = ss(As,Bs,eye(2),zeros(2)); r_sysd = c2d(r_sys,dt);
     A = r_sysd.A;B = r_sysd.B;
  
     u = sdpvar(nu,M,'full');
     o_bin = binvar(obs.number,numberofSidesObstacle,M,'full');

    x0 = sdpvar(2,1);


     Q = 10*eye(nx); R =1*eye(nu); P = 2*eye(nx);

     x = x0;
    %=======================================================================================
    % Motion Planning
    %=======================================================================================

% tic
   for k = 1:M

        [a1(:,1),a1(:,2)] = find(FRS{k}>p_th); a1_ng = (a1(:,1) -1)*dy + yvec(1); a2_ng = (a1(:,2) -1)*dx + xvec(1);
        for i=1:obs.number
            rotation_matrix = [cos(obs.heading(i)) -sin(obs.heading(i));sin(obs.heading(i)) cos(obs.heading(i))];
            i_row = (obs.pos(i,2)-ymin)/dy + 1; i_col = (obs.pos(i,1)-xmin)/dx + 1;
            
            aa1 = [a1_ng a2_ng]*rotation_matrix;
            n_locx = aa1(:,2) + obs.pos(i,1); n_locy = aa1(:,1) + obs.pos(i,2);
            n_loc_xy{i} = [n_locx n_locy]; %[xlocation  ylocation]

        a1=[];

    
 %========================================================================================
 % MPC controller
 %========================================================================================
    

         constraints = [constraints,robot.minvelocity_x <= u(1,k)<= robot.maxvelocity_x,robot.minvelocity_y <= u(2,k)<= robot.maxvelocity_y,xmin<=x(1)<=xmax,ymin<=x(2)<=ymax]; %,

         [obs_xmin,indy1] = min(n_loc_xy{i}(:,1)); [obs_ymin,indx1] = min(n_loc_xy{i}(:,2));[obs_xmax,indy2] = max(n_loc_xy{i}(:,1)); [obs_ymax,indx2] = max(n_loc_xy{i}(:,2));
         if obs.heading(i) ==0 || obs.heading(i)==pi/2 || obs.heading(i) == pi
             r0 = Polyhedron('V',[obs_xmin obs_ymin;obs_xmin obs_ymax;obs_xmax obs_ymin;obs_xmax obs_ymax]);
         else
            r0 = Polyhedron('V',[obs_xmin n_loc_xy{i}(indy1,2);obs_xmax n_loc_xy{i}(indy2,2);n_loc_xy{i}(indx1,1) obs_ymin;n_loc_xy{i}(indx2,1) obs_ymax]);
         end
         r0.minHRep();r0.minVRep();
         a = r0.A; b = r0.b;% ax<=b constraint
         if isempty(a)==0

         for ii=1:size(a,1)
          
             constraints = [constraints, -a(ii,:)*x<= -b(ii) + M_big*o_bin(i,ii,k)];
         end
            constraints = [constraints,o_bin(i,1,k) + o_bin(i,2,k) + o_bin(i,3,k) + o_bin(i,4,k)<=numberofSidesObstacle-1];
         end % end if isempty(a)
        end  % for i
         
        objective = objective + (x - (robot.Goal)')'*Q*(x - (robot.Goal)') + u(:,k)'*R*u(:,k);    % OBJECTIVE
        x = A*x + B*u(:,k);

     
   end  % for k
   
  options = sdpsettings('solver','gurobi');
  solution = optimize([constraints, x0 == robot.pos(steps,:)'],objective,options);
  if solution.problem>0
      failure = failure+1;
      t_failure(failure) = steps;
      flag=4;
      display('FAILURE')
  end


 %======================================================================================
    u_control = value(u(:,1));
    robot.pos(steps+1,1) = A(1,1)*robot.pos(steps,1) + B(1,1)*u_control(1);robot.pos(steps+1,2) = A(2,2)*robot.pos(steps,2) + B(2,2)*u_control(2); 
    x_r(steps+1) = robot.pos(steps+1,1); y_r(steps+1) = robot.pos(steps+1,2);
    U(steps,:) = u_control;
    %=======================================================================================
    clf

    rectangle('Position', [(robot.pos(steps+1,1)-0.1) (robot.pos(steps+1,2)-0.1) 0.2 0.2])
    axis([-9 2 -4 1])
    %=============================================================
    % Obstacle movement
    %=============================================================
        for i=1:obs.number
            hold on
            random_number = rand(1); velocity_indx = min(find(cumsum(obs.linearSpeedProb)>=random_number));
            obs.pos(i,:) = obs.pos(i,:) + dt*obs.linearSpeedRange(velocity_indx)*[cos(obs.heading(i)) sin(obs.heading(i))];
            o_locations(i,1,steps+1) = obs.pos(i,1); o_locations(i,2,steps+1) = obs.pos(i,2);
  
            DrawRectangle([obs.pos(i,1) obs.pos(i,2) 1 1 obs.heading(i)]);
        end
        
    
    %==============================================================
     plot(robot.Goal(1),robot.Goal(2),'go')
     plot(robot.start(1),robot.start(2),'ko')
    axis([-9 2 -4 1])
    col_x = robot.pos(steps+1,1) - obs.pos(:,1); col_y = robot.pos(steps+1,2) - obs.pos(:,2);
    collision_v = [col_x col_y];
        if min(sqrt(collision_v(:,1).^2 + collision_v(:,2).^2)) <= 0.5
            flag=2;
            display('CRASH')
        end
    
    
    if norm(robot.Goal(2) - robot.pos(steps+1,2))<=0.2 && norm(robot.Goal(1) - robot.pos(steps+1,1))<=0.2 
            flag=1;
            display('SUCCESS')
    end
    
    n_loc_xy = [];
    
    steps=steps+1;
    t=t+dt;
end
wo = 1;ho=1; % obstacle width and height

for i=1:size(o_locations,3)
    for j=1:obs.number
        o_positionx(j,i) = o_locations(j,1,i); o_positiony(j,i) = o_locations(j,2,i);o_positionz(j,i) = i;
    end
    r_positionx(i) = x_r(i); r_positiony(i) = y_r(i); r_positionz(i) = i;
end

% clearvars -except robot obs steps T dt o_positionx o_positiony x_r y_r Problem
% filename = [ 'Data', num2str(Problem),'.mat' ];
% save(filename)
