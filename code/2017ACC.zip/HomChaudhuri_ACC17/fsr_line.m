tic
clear
clc


N = 10;
xmin = -5; xmax = 40; ymin=-2;ymax = 2;
x0 = 0;y0 = 0;
dx = 0.05;dy=0.05;

digitRound=1e10;                 
                                 

obs.linearSpeedRange = [3.0 2.5 1.5 2 1.0 0.8 0.5 0.1];
obs.linearSpeedProb = [0.05,0.05,0.30,0.20,0.25,0.10,0.04,0.01];  

obs.samplePeriod = 0.6;
obs.dynamicsChangeProb = 0.1;
obs.initHeading = 0; 
obs.initMode = -1;   % -1: Random, 0: linear, 1: arc 
dt = 0.2;
Transition_Matrix = [(1-obs.dynamicsChangeProb) obs.dynamicsChangeProb;obs.dynamicsChangeProb (1-obs.dynamicsChangeProb)]; % 1 for arc; 2 for line
%============================================== 
P_space1 = zeros((ymax-ymin)/dx +1,(xmax-xmin)/dy + 1);
x0g= (x0-xmin)/dx + 1;y0g= (y0-ymin)/dy + 1;
P_space1(y0g,x0g) =1;
%===============================================
% Initial Obstacle Position
%===============================================
obs.vertices = [-0.65 -0.65;-0.65 0.65;0.65 -0.65; 0.65 0.65];
obs.vx = [min(obs.vertices(1,:)) max(obs.vertices(end,:))];obs.vy = [min(obs.vertices(1,:)) max(obs.vertices(end,:))];
R0 = Polyhedron('V',obs.vertices);
P0 = 1; % Prior distribution
k_xmin = -2; k_ymin = -2; k_xmax = 2; k_ymax = 2;

K_init = zeros((k_xmax - k_xmin)/dx + 1,(k_ymax - k_ymin)/dy + 1);

Kernel = K_init;center = [0,0];
for i1=round((min(obs.vy)-k_ymin)/dy) + 1:round((max(obs.vy)-k_ymin)/dy) + 1
    for j1=round((min(obs.vx)-k_xmin)/dx) + 1:round((max(obs.vx)-k_xmin)/dx) + 1
        i_x = (j1-1)*dx+ k_xmin; j_y = (i1-1)*dy + k_ymin; 
        
        if contains(R0,[i_x;j_y])==1
            Kernel(i1,j1) = P0;
        end
        
    end
    
end
xvec = xmin:dx:xmax;
yvec = ymin:dy:ymax;
FRS{1} = conv2(P_space1,Kernel,'same');

%====================================================
disp('Starting forward reach calculation');
theta = zeros(1,length(obs.linearSpeedRange ));

count = 0;
FF = zeros((ymax-ymin)/dy + 1,(xmax-xmin)/dx +1);
values =obs.linearSpeedRange;
prob = obs.linearSpeedProb;

for steps=1:N/dt
    [Rk(:,1),Rk(:,2)] = find(P_space1>1e-50); % Mode 1 arc
    
    alpha11 = 1; alpha22 = 1; alpha12 = 1;alpha21 = 1;
    P_space_next = zeros((ymax-ymin)/dy +1,(xmax-xmin)/dx +1);
    for j=1:length(obs.linearSpeedRange)
        P_line_next1 = zeros((ymax-ymin)/dy +1,(xmax-xmin)/dx +1);       

   %=============================================================================================
   % MODE 1: Arc
   %==============================================================================================
            ix = (Rk(:,2) - 1)*dx + xmin; iy = (Rk(:,1) - 1)*dy + ymin;
            Pindx1  = sub2ind(size(P_line_next1),Rk(:,1),Rk(:,2));

            currProb = P_space1(Pindx1); % Mode 1

            ix_plus_line = ix + dt*obs.linearSpeedRange(j)*cos(theta(j));                 
            iy_plus_line = iy + dt*obs.linearSpeedRange(j)*sin(theta(j));                  

 
            x_plus_line_grid = round((ix_plus_line - xmin)/dx + 1);

            y_plus_line_grid = round((iy_plus_line - ymin)/dy + 1);


            indx12 = sub2ind(size(P_line_next1),y_plus_line_grid,x_plus_line_grid); 
            P_line_next1(indx12) = min(alpha12*currProb*obs.linearSpeedProb(j),1);

           
        P_space_next(indx12) = P_space_next(indx12)+P_line_next1(indx12);

       
        theta(j) = 0;

        
    end   % end j
    steps
     
    P_space1 = P_space_next; 
    FRS{steps+1} = conv2(P_space1,Kernel,'same');
    
    count = count+dt;
    Rk = [];
    
end
clearvars -except FRS xvec yvec values prob N dt
% save('FSR_line.mat')

toc
