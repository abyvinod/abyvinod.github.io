---
layout: docs
title: minkSumInner.m
---

```
  Computes the scaling and shifting for the template polytope polyC
  such that it is completely contained in the polytope polyA + polyB
  If no template is provided, we use polyA as the template
```
