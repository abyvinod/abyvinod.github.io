%  Supplementary materials for the paper:
% 
%  User-interface design for MIMO LTI human-automation systems 
%  through sensor placement
%
%  Abraham P. Vinod, Tyler H. Summers, and Meeko M.K. Oishi
%
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %


You will need the following MATLAB. (Tested with 2014,2015 versions)

We discuss the UAV example in two network configurations --- the assymmetric network discussed in the paper and a symmetric network.

Each of the cases are separately considered. The following files are included:

getGamma.m    		       - Computes T(S),\gamma(S),C(S) given S\subseteq\mathcal{S}
Case1_NominalNoNoise.m     - Solves Problem 1a/1b
Case2_OffNominalNoNoise.m  - Solves Problem 2b
Case3_NominalNoise.m       - Solves Problem 3a/3b
Case4_OffNominalNoise.m    - Solves Problem 4
