%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham %
% Date: 2016-10-25                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Problem
% User-interface design under nominal operation with noise-free measurements

%% Solution
% Solve Problem 1a/1b

clear
clc

A=[0,1;0,0];
B=[0;1];
F=[-1,-4];

Sym=input('UI design for a asymmetric communication structure seen \nin the ACC 2016 paper? \n(Type 0 for yes and 1 for a symmetric network example)\n');
%% Network parameters
clc
disp('User-interface design for a UAV network');
disp('=======================================');
if Sym==1
    disp('A symmetric network example');
    fprintf('\t2 \t3\n 1\n \t4 \t5\n');
    GL=[0,0,0,0,0;
        -1,1,0,0,0;
        0,-1,1,0,0;
        -1,0,0,1,0;
        0,0,0,-1,1];
    GF=[1,0,0,0,0;
        0,0,0,0,0;
        0,0,0,0,0;
        0,0,0,0,0;
        0,0,0,0,0];
else
    disp('The network seen in ACC 2016 paper');
    fprintf('\t2\n 1\n \t3 \t4\n');
    GL=[0,0,0,0;
        -1,1,0,0;
        -1,0,1,0;
        0,0,-1,1];
    GF=[1,0,0,0;
        0,0,0,0;
        0,0,0,0;
        0,0,0,0];
end
%% Complete System parameters
IN=eye(size(GL,1));
Abar=kron(IN,A)+kron(GL,B*F);
Abar(2,1)=-6;                   % Making the state matrix stable
Abar(2,2)=-5;                   % Making the state matrix stable. Now the leader heads to origin by default
Bbar=kron(GF,B);
Bbar=Bbar(:,1);                 % Only the position of the leader UAV is accessible to the user
CtrbMatrix=ctrb(Abar,Bbar);     % Controllability matrix defined for computing the Markov parameters
NoOfStates=size(Abar,1);        % n UAVs with 2 state each =>  N=2n
mathcalS=1:NoOfStates;          % All the possible sensor positions. Used only in Off-nominal operation. This variable is implicitly assumed (hard-coded) in nominal-operation.

%% Task specification
CtaskWaypoint=zeros(1,NoOfStates);       
CtaskWaypoint(1)=1;                         % Waypoint tracking based on leader's position 
disp('Task Waypoint: [1]');
CtaskTrajectory=zeros(1,NoOfStates);
CtaskTrajectory(1:2,1:2)=eye(2);            % Trajectory tracking based on leader's position and velocity
disp('Task Trajectory: [1,2]');

%% Combinations of s_i taken two at a time
comba2=zeros(1,2);                          % Dummy combination to initialize
for i=1:NoOfStates                          % Generate the realization of ^N C_k
    for j=i+1:NoOfStates
        comba2=[comba2;i,j];
    end
end
comba2=comba2(2:end,:);                     % Remove the dummy combinatation
comba2Offset=NoOfStates;                    % When forming "all" possible sensor combination, the starting point

%% Combinations of s_i taken three at a time
comba3=zeros(1,3);                          % Dummy combination to initialize
for i=1:size(comba2,1)                      % Generate the realization of ^N C_k
    for j=max(comba2(i,:))+1:NoOfStates
        comba3=[comba3;[comba2(i,:),j]];
    end
end
comba3=comba3(2:end,:);                     % Remove the dummy combinatation
comba3Offset=NoOfStates+nchoosek(NoOfStates,2); % When forming "all" possible sensor combination, the starting point
TotalCombinations=NoOfStates+nchoosek(NoOfStates,2)+nchoosek(NoOfStates,3);
% The powerset is captured as [1:NoOfStates,comba2,comba3]
% Indexing goes from [1:NoOfStates,comba2Offset+[1:nchoosek(NoOfStates,2)],,comba3Offset+[1:nchoosek(NoOfStates,3)]

%% Compute dimension of user-observable for all combination of sensors taken one at a time and two at a time
gamma=zeros(1,TotalCombinations);            
for i=1:TotalCombinations
    if i<=NoOfStates
        gamma(i)=getGamma(i,CtrbMatrix,Abar);
    elseif i<=comba3Offset
        indx_comba=i-comba2Offset;
        gamma(i)=getGamma(comba2(indx_comba,:),CtrbMatrix,Abar);
    else
        indx_comba=i-comba3Offset;
        gamma(i)=getGamma(comba3(indx_comba,:),CtrbMatrix,Abar);
    end
end

%% Computation of T(S_{task})
fprintf('\n-> \\gamma(.) refers to the relative degree (rank(T(S))) of the\n\tinput-output model when a corresponding set of sensors are used.\n');
fprintf('-> Note that \\gamma(Task Waypoint)=\\gamma(Task Trajectory)=%d.\n',gamma(1));%,gamma(NoOfStates+1));
TtaskWaypoint=[CtaskWaypoint;
               CtaskWaypoint*Abar];      % \gamma([1])=2;
TtaskTrajectory=CtaskTrajectory;         % \gamma([1,2])=2;
% One can check that TtaskWaypoint=TtaskTrajectory means the user-interface
% design for both these tasks will have to be the same in the nominal
% operation.

%% Nominal Operation (Noise-free)
fprintf('\nNominal Operation (Noise-free)\n==============================\n');
%% Strust computation (Equation (13))
% By Proposition 2, it is a one-pass in gamma(1:NoOfStates).
[gammaMin,sensor_indx]=min(gamma(1:NoOfStates));
fprintf('\nStrust={%d} with \\gammaMin=%d which means\n',sensor_indx,gammaMin);

%% Is Sfeas (Equation (14)) empty? Equivalent to asking if s_2 \in Savail?
Cs_2=zeros(1,NoOfStates);       
Cs_2(2)=1;
Ts_2=Cs_2;
fprintf('\\gamma(Task Waypoint \\cup {s_2})=%d and \\gamma(Task Trajectory \\cup {s_2})=%d.\n',rank([Ts_2;TtaskWaypoint]),rank([Ts_2;TtaskTrajectory]));
fprintf('Clearly, s_2 \\not\\in Savail for both the tasks---Waypoint and Trajectory tracking.\n\n');
fprintf('#Using the relaxed problem to compute the user-interface, Problem 1b.\n\n');
%% Strust+ computation (Equation (16))
% Definition of Sfeas+ requires \gamma(S)\leq \gamma(Stask)=2. Clearly, if |S|>2, then \gamma(S)>2.
Strustplus=[find(gamma==1),find(gamma==2)];    % indices in [mathcalS,comba]
fprintf('Strustplus has %d elements, {',length(Strustplus));
for i=1:length(Strustplus)
    if Strustplus(i)<comba2Offset
        fprintf('{%d},',Strustplus(i));
    elseif Strustplus(i)<comba3Offset
        fprintf('{%d,%d},',comba2(Strustplus(i)-comba2Offset,1),comba2(Strustplus(i)-comba2Offset,2));
    else
        % Not required to check since \gamma(\cdot)>|3| by Proposition 2.
    end
end
fprintf('\b}.\n');

%% Sfeas+ computation (Lemma 5 and Proposition 1)
SfeasplusWaypoint=[];
SfeasplusTrajectory=[];
for i=1:length(Strustplus)
    j=Strustplus(i);
    if j<=comba2Offset
        [~,~,TS]=getGamma(j,CtrbMatrix,Abar);
        if rank([TS;TtaskWaypoint])==rank(TS)
            SfeasplusWaypoint=[SfeasplusWaypoint,j];
        end
        if rank([TS;TtaskTrajectory])==rank(TS)
            SfeasplusTrajectory=[SfeasplusTrajectory,j];
        end
    elseif j<=comba3Offset
        indx_comba=j-comba2Offset;
        [~,~,TS]=getGamma(comba2(indx_comba,:),CtrbMatrix,Abar);
        if rank([TS;TtaskWaypoint])==rank(TS)
            SfeasplusWaypoint=[SfeasplusWaypoint,j];
        end
        if rank([TS;TtaskTrajectory])==rank(TS)
            SfeasplusTrajectory=[SfeasplusTrajectory,j];
        end
    else
%% Skipping search over comba3 because minimum \gamma for members of comba3 is 4.
%         disp(min(gamma(37:end)))
%         indx_comba=j-comba3Offset;
%         [~,~,TS]=getGamma(comba3(indx_comba,:),CtrbMatrix,Abar);
%         if rank([TS;TtaskWaypoint])==rank(TS)
%             SfeasplusWaypoint=[SfeasplusWaypoint,j];
%         end
%         if rank([TS;TtaskTrajectory])==rank(TS)
%             SfeasplusTrajectory=[SfeasplusTrajectory,j];
%         end
    end
end

if sum(abs(SfeasplusTrajectory-SfeasplusWaypoint))==0
    fprintf('Sfeas+ is the same for both the tasks, {');
else
    disp('\n**Hard coding will not work**\n')
end
% fprintf('Sfeas+ has %d elements, {',length(SfeasplusWaypoint));
for i=1:length(SfeasplusWaypoint)
    if SfeasplusWaypoint(i)<comba2Offset
        fprintf('{%d},',SfeasplusWaypoint(i));
    elseif SfeasplusWaypoint(i)<comba3Offset
        fprintf('{%d,%d},',comba2(SfeasplusWaypoint(i)-comba2Offset,1),comba2(SfeasplusWaypoint(i)-comba2Offset,2));
    else
        % Not required since Sfeasplusxxx does not have elements from comba3.
    end
end
fprintf('\b}.\n');
% disp(SfeasplusWaypoint(1));
% disp(comba(SfeasplusWaypoint(2)-NoOfStates,:));
% disp(S1bTrajectory(1));
% disp(comba(S1bTrajectory(2)-NoOfStates,:));

%% S1b computation Equation (18) --- Hardcoded
fprintf('S1b for Waypoint Tracking is {%d}.\n',SfeasplusWaypoint(1));
fprintf('S1b for Trajectory Tracking is {{%d},{%d,%d}}.\n',SfeasplusWaypoint(1),comba2(SfeasplusWaypoint(2)-NoOfStates,:));
fprintf('\n=> Solving Problem 1b, we find the optimal user-interface is {%d} for \n\tboth the tasks.\n',SfeasplusWaypoint(1));
