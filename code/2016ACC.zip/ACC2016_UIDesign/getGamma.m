%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham %
% Date: 2016-10-25                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Problem
%Compute the dimension of the user observable space \gamma(S), the state
%transformation matrix T_S, and the output matrix C

%% Inputs
% Sensor combination of interest S
% Controllability matrix of the system CtrbMatrix (for computation of Markov
% parameters)
% System matrix of the networked system Abar

%% Outputs
% \gamma(S) uses Markov parameters
% T(S) uses the discussion in Section II.A
% C uses e_i notation

function [gamma,TS,C]=getGamma(S,CtrbMatrix,Abar)
    [N,~]=size(CtrbMatrix);
    cardinalityS=length(S);
    C=zeros(cardinalityS,N);
    Rowindx=zeros(1,cardinalityS);
    for i=1:cardinalityS
        C(i,S(i))=1;
    end
    MarkovParam=C*CtrbMatrix;                        % MarkovParameters=[1,1]\times C \times [B AB A^2B......A^{n-1}B]
    for i=1:cardinalityS
        Rowindx(i)=find(abs(MarkovParam(i,:))>0,1);        % Row 1, 1st non-zero indx                                                 
    end
    j=1;
    TS=C(1,:);
    for i=1:cardinalityS
        TS=[TS;C(i,:)];
        for j=1:(Rowindx(i)-1)
            TS=[TS;TS(end,:)*Abar];
            j=j+1;
        end
    end
    TS=TS(2:end,:);
    gamma=rank(TS);
%     gamma=cardinalityS*min(Rowindx); % Non-zeroness means input appears in that derivative
end
