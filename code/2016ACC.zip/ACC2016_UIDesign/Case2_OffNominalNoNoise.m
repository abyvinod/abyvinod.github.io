%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham %
% Date: 2016-10-25                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Problem
% User-interface design under off-nominal operation with noise-free measurements

%% Solution
% Solve Problem 2b

clear
clc

A=[0,1;0,0];
B=[0;1];
F=[-1,-4];

Sym=input('UI design for a asymmetric communication structure seen \nin the ACC 2016 paper? \n(Type 0 for yes and 1 for a symmetric network example)\n');
%% Network parameters
clc
disp('User-interface design for a UAV network');
disp('=======================================');
if Sym==1
    disp('A symmetric network example');
    fprintf('\t2 \t3\n 1\n \t4 \t5\n');
    GL=[0,0,0,0,0;
        -1,1,0,0,0;
        0,-1,1,0,0;
        -1,0,0,1,0;
        0,0,0,-1,1];
    GF=[1,0,0,0,0;
        0,0,0,0,0;
        0,0,0,0,0;
        0,0,0,0,0;
        0,0,0,0,0];
else
    disp('The network seen in ACC 2016 paper');
    fprintf('\t2\n 1\n \t3 \t4\n');
    GL=[0,0,0,0;
        -1,1,0,0;
        -1,0,1,0;
        0,0,-1,1];
    GF=[1,0,0,0;
        0,0,0,0;
        0,0,0,0;
        0,0,0,0];
end
%% Complete System parameters
IN=eye(size(GL,1));
Abar=kron(IN,A)+kron(GL,B*F);
Abar(2,1)=-6;                   % Making the state matrix stable
Abar(2,2)=-5;                   % Making the state matrix stable. Now the leader heads to origin by default
Bbar=kron(GF,B);
Bbar=Bbar(:,1);                 % Only the position of the leader UAV is accessible to the user
CtrbMatrix=ctrb(Abar,Bbar);     % Controllability matrix defined for computing the Markov parameters
NoOfStates=size(Abar,1);        % n UAVs with 2 state each =>  N=2n
mathcalS=1:NoOfStates;          % All the possible sensor positions. Used only in Off-nominal operation. This variable is implicitly assumed (hard-coded) in nominal-operation.

%% Task specification
CtaskWaypoint=zeros(1,NoOfStates);       
CtaskWaypoint(1)=1;                         % Waypoint tracking based on leader's position 
disp('Task Waypoint: [1]');
CtaskTrajectory=zeros(1,NoOfStates);
CtaskTrajectory(1:2,1:2)=eye(2);            % Trajectory tracking based on leader's position and velocity
disp('Task Trajectory: [1,2]');
%% Combinations of s_i taken two at a time
comba2=zeros(1,2);                          % Dummy combination to initialize
for i=1:NoOfStates                          % Generate the realization of ^N C_k
    for j=i+1:NoOfStates
        comba2=[comba2;i,j];
    end
end
comba2=comba2(2:end,:);                     % Remove the dummy combinatation
comba2Offset=NoOfStates;                    % When forming "all" possible sensor combination, the starting point

%% Combinations of s_i taken three at a time
comba3=zeros(1,3);                          % Dummy combination to initialize
for i=1:size(comba2,1)                      % Generate the realization of ^N C_k
    for j=max(comba2(i,:))+1:NoOfStates
        comba3=[comba3;[comba2(i,:),j]];
    end
end
comba3=comba3(2:end,:);                     % Remove the dummy combinatation
comba3Offset=NoOfStates+nchoosek(NoOfStates,2); % When forming "all" possible sensor combination, the starting point
TotalCombinations=NoOfStates+nchoosek(NoOfStates,2)+nchoosek(NoOfStates,3);
% The powerset is captured as [1:NoOfStates,comba2,comba3]
% Indexing goes from [1:NoOfStates,comba2Offset+[1:nchoosek(NoOfStates,2)],,comba3Offset+[1:nchoosek(NoOfStates,3)]

%% Compute dimension of user-observable for all combination of sensors taken one at a time and two at a time
gamma=zeros(1,TotalCombinations);            
for i=1:TotalCombinations
    if i<=NoOfStates
        gamma(i)=getGamma(i,CtrbMatrix,Abar);
    elseif i<=comba3Offset
        indx_comba=i-comba2Offset;
        gamma(i)=getGamma(comba2(indx_comba,:),CtrbMatrix,Abar);
    else
        indx_comba=i-comba3Offset;
        gamma(i)=getGamma(comba3(indx_comba,:),CtrbMatrix,Abar);
    end
end

%% Computation of T(S_{task})
fprintf('\n-> \\gamma(.) refers to the relative degree (rank(T(S))) of the\n\tinput-output model when a corresponding set of sensors are used.\n');
fprintf('-> Note that \\gamma(Task Waypoint)=\\gamma(Task Trajectory)=%d.\n',gamma(1));%,gamma(NoOfStates+1));
TtaskWaypoint=[CtaskWaypoint;
               CtaskWaypoint*Abar];      % \gamma([1])=2;
TtaskTrajectory=CtaskTrajectory;         % \gamma([1,2])=2;
% One can check that TtaskWaypoint=TtaskTrajectory means the user-interface
% design for both these tasks will have to be the same in the nominal
% operation.

%% Off-nominal (Noise-free)
fprintf('\nOff-Nominal Operation (Noise-free)\n==================================\n');

%% Computation of gammaMax
gammaMax=getGamma(mathcalS,CtrbMatrix,Abar); % Non-zeroness means input appears in that derivative
fprintf('\nOptimal solution(s) found using brute force upto cardinality of 3 is\n');
SoffNomRestrictedTo3=find(gamma==gammaMax);
fprintf('\t{');
for i=1:length(SoffNomRestrictedTo3)
    if SoffNomRestrictedTo3(i)<comba2Offset
        fprintf('{%d},',SoffNomRestrictedTo3(i));
    elseif SoffNomRestrictedTo3(i)<comba3Offset
        fprintf('{%d,%d},',comba2(SoffNomRestrictedTo3(i)-comba2Offset,1),comba2(SoffNomRestrictedTo3(i)-comba2Offset,2));
    else
        fprintf('{%d,%d,%d},',comba3(SoffNomRestrictedTo3(i)-comba3Offset,1),comba3(SoffNomRestrictedTo3(i)-comba3Offset,2),comba3(SoffNomRestrictedTo3(i)-comba3Offset,3));
    end
end
fprintf('\b}.\n');

%% Implementation of Algorithm 2
possib=mathcalS;
Sgreedy=[];
maxgammaGreedy=zeros(1,NoOfStates);
maxgammaGreedyindx=1;                               
gammaSSubOpt=0;
while gammaSSubOpt<gammaMax                            % While we have not chosen enough sensor positions
    gammaGreedy=zeros(1,length(possib));
    for i=1:length(possib)
        SgreedyTemp=[Sgreedy,possib(i)];
        gammaGreedy(i)=getGamma(SgreedyTemp,CtrbMatrix,Abar)-maxgammaGreedy(maxgammaGreedyindx);
    end
    [maxgammaGreedy(maxgammaGreedyindx+1),indx_possib]=max(gammaGreedy);      % Find the argmax \Delta(a|S_i)
    Sgreedy=[Sgreedy,possib(indx_possib)];
    gammaSSubOpt=getGamma(Sgreedy,CtrbMatrix,Abar);
    possib=possib(possib~=possib(indx_possib));          % Shrink the possible sensor placement opportunities    
    maxgammaGreedyindx=maxgammaGreedyindx+1;    
end
SAlgo2=sort(Sgreedy);
fprintf('Corollary 2 makes the user-interface design independent of the task.\n');
fprintf('\n=> Solving Problem 2b using Algorithm 2, we get {%d,%d,%d} as the \n\toptimal user-interface for both the tasks.\n',SAlgo2);
