%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham                                   %
% Date: 2016-08-18                                                  %
% Purpose: > Validate the results of Case 1 with Monte Carlo        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Problem
% Validate the simulation result obtained for Case 1

fprintf('> Validating the estimated CapturePr optimal values using MonteCarlo simulations.\n');
while ~exist('contour_plot_for_visual_confirmation','var')
    input('Please run Case1_GaussianNoise.m first!');
end
if contour_plot_for_visual_confirmation==0
    fprintf('> Not plotting the contour plots for visual comparison.\n');
    fprintf('> Set contour_plot_for_visual_confirmation=1 for comparing the pdf\nwith Monte Carlo simulation.\n\n');
end

number_of_particles=500000;                                                % No of Monte Carlo (MC) particles
prob_of_capture=zeros(1,time_horizon);                                     % MC-estimated probability of capture
error_prob=zeros(1,time_horizon);
Ctrb_robotG=B_robotG;    

for time_of_capture=1:time_horizon
    %% Optimal intercept point and the net
    % robotR_optimal_position includes t=0 position
    x_final=robotR_optimal_position(:,time_of_capture+1);
    robotR_CaptureSet=x_final+robotR_capture_box;
    
    %% Controllability matrix
    if time_of_capture>1
        Ctrb_robotG=[Ctrb_robotG,A_robotG*Ctrb_robotG(:,[end-1,end])];     % Controllability matrix definition for robot G
    end
        
    %% Monte-Carlo simulation of where robot G can travel
    x_robotG_no_disturbance_reachable=A_robotG^time_of_capture*x_robotG_init; 
    mu_robotG=x_robotG_no_disturbance_reachable+Ctrb_robotG*kron(ones(time_of_capture,1),mu_robotG_vec);
    Sigma_robotG=Ctrb_robotG*kron(eye(time_of_capture),sigma_robotG)*Ctrb_robotG';
    R=chol(Sigma_robotG);
    x_robotG_particles_MC=repmat(mu_robotG,1,number_of_particles)+R'*randn(2,number_of_particles);

    %% Count the number of "darts" that lay inside the CaptureSet --- MC-estimation of probability of capture
    capture_vector=robotR_CaptureSet.contains(x_robotG_particles_MC);
    prob_of_capture(time_of_capture)=sum(capture_vector)/number_of_particles;
    
    %% Compute the error in the predicted probability (HSCC 2017) and the estimation
    error_prob(time_of_capture)=prob_capture(time_of_capture)-prob_of_capture(time_of_capture);    
    fprintf('Error at t=%2d in CapturePr estimate: %1.3f (%1.3f - %1.3f)\n',time_of_capture,error_prob(time_of_capture),prob_capture(time_of_capture),prob_of_capture(time_of_capture));

    %% Comparing MC simulation and the analytical expression
    if contour_plot_for_visual_confirmation==1
        pdf_robotG=mvnpdf(X_env,mu_robotG',Sigma_robotG);
        max_pdf_robotG_contour=max(pdf_robotG)*1.2;
        contour_limits=0:max_pdf_robotG_contour/10:max_pdf_robotG_contour;

        % Histogram of the pdf based on the realizations with 2D support
        cnt=hist3(x_robotG_particles_MC',{x_env' y_env'});
        % fdx is given by cnt/number of particles
        cnt=cnt/number_of_particles;
        % where dx=x_inc*x_inc
        cnt=cnt/x_inc/x_inc;

        figure(200+time_of_capture)    
        clf
        contour(x_env,y_env,reshape(pdf_robotG,grid_number,grid_number),'-');
        hold on;
        contour(x_env,y_env,cnt','--');
        title(sprintf('Plot centered at mean positon of robotG\nSolid contour --- mvnpdf; Dotted --- MC estimation'));
        set(gca,'FontSize',20)
        plot(robotR_CaptureSet,'alpha',0.5,'color','red');
        axis([mu_robotG(1)-2,mu_robotG(1)+2,mu_robotG(2)-2,mu_robotG(2)+2]);
        axis square
        xlabel('Position (x)');
        ylabel('Position (y)');
        caxis manual
        caxis([0.01 0.9]);
        cb=colorbar;
        box on;
        axis square    
        grid on;
        drawnow    
    end
end

%% Plot of the Monte-carlo based experimental verification of our analytical results --- Figure 2
figure(101);
clf
subplot(2,1,1);
stem(prob_capture,'ro');
set(gca,'FontSize',20);
ylabel('$\mathrm{CapturePr}_{\bar{x}_R}(t,\bar{x}_R^\ast[t])$','interpreter','latex');
hold on;
grid on;
box on;
% Moving the ylabel a bit downwards
ylabel_handle=get(gca,'YLabel');
ylabel_handle.Position(1)=ylabel_handle.Position(1)+0.2;
ylabel_handle.Position(2)=ylabel_handle.Position(2)-0.02;
stem(prob_of_capture,'bx');
legend('Analytical expression','Monte-Carlo simulation');
set(gca,'GridAlpha',0.3);
set(gca,'xlim',[0,time_horizon+1]);
subplot(2,1,2);
stem(error_prob);
set(gca,'FontSize',20);
xlabel('Time $(t)$','interpreter','latex');
ylabel('$\mathrm{Error}$','interpreter','latex');
grid on;
box on;
set(gca,'GridAlpha',0.3);
set(gca,'xlim',[0,time_horizon+1]);
if savefigures_yes
    print(strcat(save_path_for_figures,'\\Verification.png'),'-dpng');
    savefig(strcat(save_path_for_figures,'\\Verification.fig'));
    savefile=strcat(save_path_for_figures,'\\FwdStochReach_PM_gauss.mat');
    save(savefile)
end
