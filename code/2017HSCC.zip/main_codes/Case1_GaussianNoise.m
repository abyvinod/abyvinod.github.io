%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham                                   %
% Date: 2016-08-18                                                  %
% Purpose: > Generates Figures 1,2                                  %
%          > Implementation of Subsection 4.1                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Problem -- Case 1. Goal robot with point mass dynamics
% Problem 2 solved with dynamics (20) in HSCC 2017 paper --- Maximize the
% probability of robot R capture robot G within the time horizon.

%% System
% Robot R has point mass dynamics
% Robot G has point mass dynamics
% Velocity input to Robot G is a multivariate Gaussian random vector
% Robot G has its FSRPD given by Proposition 1.
% Reach set of Robot R is forced to move forward due to the input space. 

%% Solution (overview)
% > Solve the optimization ProbC for every time instant within the time 
%   horizon. We solve ProbB by taking max over the solutions to ProbC.
% > Solve ProbD using CVX
% > Validate the results using Monte Carlo Simulations
% > Save the plots in the folder Case 1
% Computation time includes Reach computation time, solving the
% optimization solution using fmincon, and the optimal controller computation
% using CVX

%% Notes
% CapturePr has been defined using mvncdf. It can be changed to characteristic 
%   function based analysis (objective_function_mvn_CF) at the cost of 
%   higher computation time. Change the objective at Line 208.
% Different starting cases have been commented out in Lines 49-68
% While initial conditions can be changed, the code has been hardcoded for
%   the dynamics --- point mass dynamics for both robotR and robotG
% Cost for ProbD is J_\pi=0. It can be changed at Line 228-229.
% Silently runs mpt_init and (cvx_setup)

close all
clear
clc
addpath(genpath('../helper_codes'));
% Silently initialize MPT
evalc('mpt_init');

%%%%%%%%%%%%%%%%%%%%%%%%%% Modifiable parameters %%%%%%%%%%%%%%%%%%%%%%%%%%
%% Parameters for the problem: Initial positions of the robotR and robotG + Gaussian Properties
%% Eg. 1: Independent along dimensions with identical variances across dimensions
% mu_robotG_vec=[0;0];
% sigma_robotG=1*eye(2);
% x_robotR_init = [0;-3];
% x_robotG_init = [1.5;-0.5];
% axis_vec=[-3,8,-6,5];                                                     % The figure axis | xmin,xmax,ymin,ymax for the environment
% legendShow=4;                                                              % Show legends for the plot number
%% Eg. 2: Independent along dimensions with different variances across dimensions
% mu_robotG_vec=[0;0];
% sigma_robotG=0.1*[1,0;0,16];
% x_robotR_init = [0;-3];
% x_robotG_init = [1.5;-0.5];
% axis_vec=[-3,8,-6,5];                                                     % The figure axis | xmin,xmax,ymin,ymax for the environment
% legendShow=4;                                                              % Show legends for the plot number
%% Eg. 3: Dependent dimensions
mu_robotG_vec=[1.3;0.3];
sigma_robotG=0.1*[5,8;8,20];   
x_robotG_init = [-3;0];
x_robotR_init = [-3;-2];
axis_vec=[-3.5,5.5,-2.5,6.5];                                              % The figure axis | xmin,xmax,ymin,ymax for the environment
legendShow=4;                                                              % Show legends for the plot number
%% Input space of RobotR is the same across dimensions
%% RobotR can hang around at the same spot or move forward
% u_robotR_min=0;
% u_robotR_max=1;
%% RobotR is forced to move forward
u_robotR_min=1;
u_robotR_max=2;
%% Parameters for simulation
time_horizon=20;                                                           % Time horizon of interest T (no. of time steps)
capture_set_half_edge=0.25;                                                % Half of the edge of the CaptureSet, a/2
bounds_on_integral=30;                                                     % Required only if CapturePr is defined using CF approach instead of the faster mvncdf
%% Parameters for plots
timeBox=1;                                                                 % Create boxes describing time and probability of capture
create_plots_used_in_paper_only=1;                                         % 1 - Only relevant plots | 0 - All plots
savefigures_yes=0;                                                         % Save these figures in the path mentioned below
save_path_for_figures=strcat(pwd,'\Case1');
contour_plot_for_visual_confirmation=0;                                    % Plot contour plots of the pdf and compare it with the contour plot estimated from MonteCarlo simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Parameters that are hard-coded
threshold_FSRPM=10^-9;                                                     % Epsilon value defined in (25)
sampling_time_period=0.2;                                                  % Sampling time T_s
%% Controllability matrix computation is hardcoded for a nx2 input matrix
%% RobotG has point mass dynamics 
A_robotG=eye(2);
B_robotG=sampling_time_period*eye(2);
%% RobotR has point mass dynamics 
A_robotR=A_robotG;
B_robotR=B_robotG;

%%%%%%%%%%%%%%%%%%%%%%%%%%% Program Begins %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Decide if all plots are required or only ones relevant for the paper
if create_plots_used_in_paper_only==1                                      
    vec_for_figures=[4,5,6,14,20];                                         % Time instants of interest (for the plots in the paper)
    fprintf('> Displaying only the relevant plots. Set create_plots_used_in_paper_only to 0\n\tto obtain all the plots.\n');
    fprintf('> Set timeBox to zero to reproduce the plots exactly.\n');
else                                                                       % Setting it to 0 will create all the plots
    vec_for_figures=1:time_horizon;                                        % Plot all figures
    fprintf('> Displaying all the plots. Set create_plots_used_in_paper_only to 1\n\tto obtain only the plots used in the paper.\n');
end
if savefigures_yes==1
    if isdir(save_path_for_figures)==0
        mkdir(save_path_for_figures);                                          % Create the folder if it isn't present
        disp('> Created a folder named Case1 in the pwd to save the figures to.')
    end
else
    fprintf('> Set savefigures_yes to 1 to save the plots in\n\t%s\n',save_path_for_figures);
end
%% Detect if CVX is there
is_cvx_installed=exist('cvx');
if is_cvx_installed>0
    open_loop_policy_generate=1;                                           % Generate open-loop policy and store it in the cell opt_policy
    fprintf('> Found CVX for computing the optimal control policy and\n\tinitial guess for optimization.\n');
    evalc('cvx_setup');
else                                                                       % If this is not true, then set open_loop_policy_generate=0
    open_loop_policy_generate=0;                                           
    fprintf('> You will need CVX to compute the optimal control policy and\n\tinitial guess for optimization.\n');
    fprintf('> Continuing without generating either.\n\n');
end

%% Create gridded environment for contour plot (Presentation purposes only)
x_min=axis_vec(1);
x_max=axis_vec(2);
x_inc=0.1;
y_min=axis_vec(3);
y_max=axis_vec(4);
y_inc=0.1;
x_env=x_min:x_inc:x_max;
y_env=y_min:y_inc:y_max;
grid_number=length(x_env);
if grid_number~=length(y_env)
    disp('Not a square axis_vec')
end
X_env=allcomb(x_env,y_env);                                                % All combinations of the elements of x_env

%% RobotR capture box
robotR_capture_box=Polyhedron('lb',-[capture_set_half_edge;capture_set_half_edge],'ub',[capture_set_half_edge;capture_set_half_edge]);

%% Optimization variables
prob_capture=zeros(1,time_horizon);                                        % Probability of captureful capture
robotG_mean_position=x_robotG_init;                                        % Vector of robotG_mean positions. Initialized to initial position
robotR_optimal_position=x_robotR_init;                                     % Vector of robotR optimal positions of capture. Initialized to initial position
elapsedTime=zeros(time_horizon+1,1);                                       % Stores time elapsed for each time instant and overall max
Ctrb_robotG=B_robotG;                                                      % Controllability matrix definition for robot G
Ctrb_robotR=B_robotR;                                                      % Controllability matrix definition for robot R
    
%% ProbC evaluation for each time instant
%Set timeBox to 0 to reproduce the figures without the annotations.
fprintf('> For more details on the plots, see the Figure 1 in the HSCC paper.\n\n');
for time_of_capture=1:time_horizon
    timerVal=tic;  
    
    %% Computation of the controllability matrices
    if time_of_capture>1
        Ctrb_robotG=[Ctrb_robotG,A_robotG*Ctrb_robotG(:,[end-1,end])];     % Controllability matrix definition for robot G
        Ctrb_robotR=[Ctrb_robotR,A_robotR*Ctrb_robotR(:,[end-1,end])];     % Controllability matrix definition for robot R    
    end
    
    %% Fwd reachability of robotR using (19) and MPT
    x_robotR_no_input_reachable=A_robotR^time_of_capture*x_robotR_init; 
    u_robotR_box=Polyhedron('lb',u_robotR_min*ones(2*time_of_capture,1),'ub',u_robotR_max*ones(2*time_of_capture,1));
    x_robotR_reachable=x_robotR_no_input_reachable+u_robotR_box.affineMap(Ctrb_robotR,'fourier');
        
    %% Evaluation of mu_G and sigma_G based on Proposition 1.
    x_robotG_no_disturbance_reachable=A_robotG^time_of_capture*x_robotG_init; 
    mu_robotG=x_robotG_no_disturbance_reachable+Ctrb_robotG*kron(ones(time_of_capture,1),mu_robotG_vec);
    Sigma_robotG=Ctrb_robotG*kron(eye(time_of_capture),sigma_robotG)*Ctrb_robotG';
    robotG_mean_position=[robotG_mean_position,mu_robotG];                 % For bookkeeping

    %% For numerical stability, find the bounding box (FSRreach_polytope) for the ellipse with \psi_{x_G}>threshold (25)
    [eigVec,eigVal]=eig(Sigma_robotG);                                            % Find the eigen vectors and values of the Sigma matrix
    % Translate the threshold on \psi to a threshold on x
    threshold_FSRReach=-2*log(2*pi*det(Sigma_robotG)*threshold_FSRPM/robotR_capture_box.volume);
    % Scale the threshold on x based on the eigenvalues
    H_FSRreach_polytope=[kron([1;-1],eigVec'),diag(kron(eye(2),eigVal)*threshold_FSRReach)];
    % Polytope centered about the mean position of robotG
    FSRreach_polytope=mu_robotG+Polyhedron('H',H_FSRreach_polytope);
    
    %% Feasible solution space is reach set of robotR intersected with FSRreach_polytope
    x_robotR_reachable_FSR=x_robotR_reachable.intersect(FSRreach_polytope);
    A_inequalities=x_robotR_reachable_FSR.A;
    b_inequalities=x_robotR_reachable_FSR.b;
%     fprintf('MPT is the bottleneck --- Pre-optimization took %1.2f seconds\n',round(toc(timerVal)*100)/100);
    %% Optimization problem --- Problem ProbC
    if x_robotR_reachable_FSR.isEmptySet==0                                % If the intersection is non-empty        
        if is_cvx_installed>0
            %% Solve an optimization problem for projecting the mean to the reachable set
            cvx_begin quiet
                variable initial_guess_for_fmincon_cvx_variable(2)
                minimize (norm(initial_guess_for_fmincon_cvx_variable-mu_robotG))
                A_inequalities*initial_guess_for_fmincon_cvx_variable <= b_inequalities;
            cvx_end
            initial_guess_for_fmincon=value(initial_guess_for_fmincon_cvx_variable);
        else
            %% Pick one of the vertices of the above polytope as the initial guess. 
            % It doesn't matter because of the convexity of the optimization problem.
            initial_guess_for_fmincon=x_robotR_reachable_FSR.V(1,:)';
        end        
        %% Use characteristic function based objective
%         fun = @(x)-log(objective_function_mvn_2D_CF(x,capture_set_half_edge,mu_robotG,Sigma_robotG,bounds_on_integral));
        %% Use mvncdf based objective (Faster)
        fun = @(x)-log(objective_function_mvn_2D(x,capture_set_half_edge,mu_robotG,Sigma_robotG));        
        options=optimoptions('fmincon','Display','off');
        %% Solve Problem ProbC
        [x_robotR_capture,prob_capture_current] = fmincon(fun,initial_guess_for_fmincon,A_inequalities,b_inequalities,[],[],[],[],[],options);    
    else
        %% Feasible solution space is empty
        disp('Constraint set is empty');
        x_robotR_capture=x_robotR_reachable.V(1,:)';
        prob_capture_current=Inf;
    end
    prob_capture(time_of_capture)=exp(-prob_capture_current);              % - because maximization is required from fmincon; exp to undo the effect of log
    robotR_optimal_position=[robotR_optimal_position,x_robotR_capture];    % Optimal robotR position for this instant and the box

    %% Open-loop policy generation --- Problem ProbD
    if open_loop_policy_generate==1 && x_robotR_reachable_FSR.isEmptySet==0
        displacement=x_robotR_capture-x_robotR_no_input_reachable;                % Equivalent to displacement=x_final-x_robotR_init;    
        cvx_begin quiet
            variable u(2*time_of_capture)
            %minimize (norm(u,2))                                          % Minimal control effort
            minimize 0                                                     % A feasible control policy
            u >= u_robotR_min;
            u <= u_robotR_max;
            Ctrb_robotR*u==displacement;
        cvx_end
        %disp(cvx_status)
        opt_policy{time_of_capture}=reshape(u,2,[]);
    else
        opt_policy{time_of_capture}=NaN;
    end
    
    elapsedTime(time_of_capture)=toc(timerVal);                            % Solution time to solve ProbC,ProbD
    if x_robotR_reachable_FSR.isEmptySet==0 
        fprintf('Solved at time t=%2d with capture probability: %1.4f in %1.2f seconds\n',time_of_capture,exp(-prob_capture_current),round(elapsedTime(time_of_capture)*100)/100);    
    end
    
    %% Figure plotting --- To get it in the shape of the plots in the paper --- Figure 1
    if sum(time_of_capture==vec_for_figures)==0                            % Is this a plot of interest?
        continue                                                           % If not...
    end
    
    figure(time_of_capture);
    hold on;
    plot(robotG_mean_position(1,:),robotG_mean_position(2,:),'ko-','markersize',3,'linewidth',2); % RobotG mean positions so far    
    indx_opt_not=find(prob_capture(1:time_of_capture-1)<=10^-8);           % RobotR previous intercepts with zero probability of capture.
    plot(robotR_optimal_position(1,[1,1+indx_opt_not]),robotR_optimal_position(2,[1,1+indx_opt_not]),'rx','markersize',6,'linewidth',2);
    indx_opt=find(prob_capture(1:time_of_capture-1)>10^-8);                % RobotR previous intercepts with non-zero probability of capture. The current will be surrounded by box.
    plot(robotR_optimal_position(1,1+indx_opt),robotR_optimal_position(2,1+indx_opt),'rd','markersize',6,'linewidth',2); % Shift the points by 1 to accomodate the initial point
    if (time_of_capture==legendShow) 
        % First time everything becomes clear
        legend('Robot G mean position','Previous infeasible x_R[\tau]','Previous optimal x_R^\ast[\tau]','location','North');
        xlabel('Position (x)');
        ylabel('Position (y)');
    end
    if timeBox
        dim=[0.55 0.01 0.3 0.3];
        str = sprintf('Time: %2d\nProb: %1.3f',time_of_capture,prob_capture(time_of_capture));
        a=annotation('textbox',dim,'String',str,'FitBoxToText','on');
        a.FontSize = 14;
    end
    %% Reach set plot
    plot(x_robotR_reachable,'Color','blue','alpha',0.1);
    % plot(FSRreach_polytope,'Alpha',0.3,'Color','green');    
    % Optimal robotR position for this instant and the box
    plot(x_robotR_capture+robotR_capture_box,'alpha',0.5,'color','red');
    plot(x_robotR_capture(1),x_robotR_capture(2),'ks','markerfacecolor',zeros(1,3));
    pdf_robotG=mvnpdf(X_env,mu_robotG',Sigma_robotG);                      % Contours might be a bit more higher than we have as max
    contour(x_env,y_env,reshape(pdf_robotG,grid_number,grid_number),7,'linewidth',2);
    caxis manual
    caxis([0.01 0.9]);
    cb=colorbar;
    % Flip items on the plot to bring the points marked in the beginning up front
    set(gca,'children',flipud(get(gca,'children')))
    
    box on;
    set(gca,'FontSize',20);
    axis(axis_vec);
    axis square    
    grid on;
    grid minor;
    drawnow 
    %% Save figures
    if savefigures_yes
        print(strcat(save_path_for_figures,sprintf('\\time%d.png',time_of_capture)),'-dpng');
        savefig(strcat(save_path_for_figures,sprintf('\\time%d.fig',time_of_capture)));
    end
end

%% Max over time --- Problem ProbB
timerVal=tic;  
[max_prob,time_of_capture_opt]=max(prob_capture);
elapsedTime(time_of_capture+1)=toc(timerVal);

%% Concluding message
% time_of_capture+1 to account for the fact that t starts from zero while indexing starts from 1.    
fprintf('\nThe optimal point of intercept is:\n\tTime of Intercept=%d,\n\tOptimal position of Robot R=(%1.1f,%1.1f),\n\tMean position of Robot G=(%1.1f,%1.1f),\n\tCapture Probability=%1.4f,\n\tComputation time=%f seconds.\n\n',time_of_capture_opt,robotR_optimal_position(1,time_of_capture_opt+1),robotR_optimal_position(2,time_of_capture_opt+1),robotG_mean_position(1,time_of_capture_opt+1),robotG_mean_position(2,time_of_capture_opt+1),max_prob,sum(elapsedTime));
if open_loop_policy_generate==1
    disp('The optimal open-loop policy is stored in the cell opt_policy.');
    fprintf('\n');
end

%% Capture probability over time plot --- Plotted only if required
if create_plots_used_in_paper_only==0  
    figure(time_horizon+1);
    clf
    stem(1:time_horizon,prob_capture,'linewidth',2);
    xlabel('Time $(t)$','interpreter','latex');
    ylabel('$\mathrm{CapturePr}_{\bar{x}_R}(t,\bar{x}_R^\ast[t])$','interpreter','latex');
    title('Optimal capture probability attainable vs time of capture','interpreter','latex');
    set(gca,'FontSize',20);
    box on;
    grid on;
    if savefigures_yes
        print(strcat(save_path_for_figures,'\\SuccessProb.png'),'-dpng');
        savefig(strcat(save_path_for_figures,'\\SuccessProb.fig'));
    end
end
Case1_GaussianNoise_MonteCarloValidation
