%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham                                   %
% Date: 2016-08-18                                                  %
% Purpose: > Validate the results of Case 2 with Monte Carlo        %
%          > Generate the contour plot using Monte Carlo for Fig. 3 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Problem
% Validate the simulation result obtained for Case 2

fprintf('> Validating the estimated CapturePr optimal values using MonteCarlo simulations.\n');
while ~exist('lambda_robotG_x','var')
    input('Please run Case2_ExpNoise.m first!');
end
number_of_particles=500000;                                                % No of Monte Carlo (MC) particles
prob_of_capture=zeros(1,time_horizon);                                     % MC-estimated probability of capture
error_prob=zeros(1,time_horizon);
Ctrb_robotG=B_robotG;    

for time_of_capture=1:time_horizon
    %% Optimal intercept point and the net
    % robotR_optimal_position includes t=0 position
    x_final=robotR_optimal_position(:,time_of_capture+1);
    robotR_CaptureSet=[x_final(1);0;x_final(2);0]+capture_set_box;
    
    %% Controllability matrix
    if time_of_capture>1
        Ctrb_robotG=[Ctrb_robotG,A_robotG*Ctrb_robotG(:,[end-1,end])];     % Controllability matrix definition for robot G
    end
        
    %% Monte-Carlo simulation of where robot G can travel
    random_vector_x=exprnd(1/lambda_robotG_x,time_of_capture,number_of_particles);
    random_vector_y=exprnd(1/lambda_robotG_y,time_of_capture,number_of_particles);
    random_vector=[];
    random_vector(1:2:2*time_of_capture,:)=random_vector_x;
    random_vector(2:2:2*time_of_capture,:)=random_vector_y;
    offset_natural_dynamics_robotG=A_robotG^time_of_capture*x_robotG_init;
    x_robotG_natural_dynamics=repmat(offset_natural_dynamics_robotG,1,number_of_particles);
    x_robotG_particle=x_robotG_natural_dynamics+Ctrb_robotG*random_vector;
    
    %% Count the number of "darts" that lay inside the CaptureSet --- MC-estimation of probability of capture
    catch_vector=robotR_CaptureSet.contains(x_robotG_particle);
    prob_of_capture(time_of_capture)=sum(catch_vector)/number_of_particles;
    
    %% Compute the error in the predicted probability (HSCC 2017) and the estimation
    error_prob(time_of_capture)=prob_capture(time_of_capture)-prob_of_capture(time_of_capture);
    fprintf('Error in the success probability: %1.3f (%1.3f - %1.3f)\n',error_prob(time_of_capture),prob_capture(time_of_capture),prob_of_capture(time_of_capture));
    
    %% Comparing MC simulation and the analytical expression
    if create_plots_used_in_paper_only==1
        if sum(time_of_capture==vec_for_figures)==0                            % Is this not a plot of interest?
            continue
        end
    end
    figure(time_of_capture)                                                % Reuse the figures and update them with contour plots 
    hold on;
    % Histogram of the pdf based on the realizations with 2D support --- plots it
    [h,cbins,xbins,ybins]=hexscatter(x_robotG_particle(1,:)',x_robotG_particle(3,:)',contour_plot_max);
    set(gca,'children',flipud(get(gca,'children')))
    caxis manual
    caxis([0.0001 contour_plot_max]);
    colorbar        
    axis(axis_vec)
    axis square
    drawnow    
    if savefigures_yes
        print(strcat(save_path_for_figures,sprintf('\\time%d.png',time_of_capture)),'-dpng');
        savefig(strcat(save_path_for_figures,sprintf('\\time%d.fig',time_of_capture)));
    end
end






%% Plot of the Monte-carlo based experimental verification of our analytical results
figure(101);
clf
subplot(2,1,1);
stem(prob_capture,'ro');
set(gca,'FontSize',20);
ylabel('$\mathrm{CapturePr}_{\bar{x}_R}(t,\bar{x}_R^\ast[t])$','interpreter','latex');
hold on;
grid on;
box on;
% Moving the ylabel a bit downwards
ylabel_handle=get(gca,'YLabel');
ylabel_handle.Position(1)=ylabel_handle.Position(1)+0.2;
ylabel_handle.Position(2)=ylabel_handle.Position(2)-0.02;
stem(prob_of_capture,'bx');
legend('Analytical expression','Monte-Carlo simulation');
set(gca,'GridAlpha',0.3);
set(gca,'xlim',[0,time_horizon+1]);
subplot(2,1,2);
stem(error_prob);
set(gca,'FontSize',20);
xlabel('Time $(t)$','interpreter','latex');
ylabel('$\mathrm{Error}$','interpreter','latex');
grid on;
box on;
set(gca,'GridAlpha',0.3);
set(gca,'xlim',[0,time_horizon+1]);
if savefigures_yes
    print(strcat(save_path_for_figures,'\\Verification.png'),'-dpng');
    savefig(strcat(save_path_for_figures,'\\Verification.fig'));
    savefile=strcat(save_path_for_figures,'\\FwdStochReach_DI_exp.mat');
    save(savefile)
end
