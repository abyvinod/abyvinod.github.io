%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham                                   %
% Date: 2016-08-18                                                  %
% Purpose: > Generates Figures 3,4                                  %
%          > Implementation of Subsection 4.2                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Problem -- Case 2. Goal robot with double integrator dynamics
% Problem 2 solved with dynamics (21) in HSCC 2017 paper --- Maximize the
% probability of robot R capture robot G within the time horizon.

%% System
% Robot R has point mass dynamics
% Robot G has double integrator dynamics
% Acceleration input to Robot G are exponential random variable along  each dimension
% Robot G has its FSRPD given by Proposition 3.
% Reach set of Robot R is forced to move forward due to the input space. 

%% Solution (overview)
% > Solve the optimization ProbC for every time instant within the time 
%   horizon. We solve ProbB by taking max over the solutions to ProbC.
% > Solve ProbD using CVX
% > Validate the results using Monte Carlo Simulations
% > Save the plots in the folder Case 2
% Computation time includes Reach computation time, solving the
% optimization solution using fmincon, and the optimal controller computation
% using CVX

%% Notes
% The capture_box in 2-D, and CapturePr has been defined using 
%   objective_function_exp_2D_CF (30).
% Different starting cases have been commented out in Lines 49-70
% While initial conditions can be changed, the code has been hardcoded for
%   the dynamics --- point mass dynamics for both robotR and robotG
% Cost for ProbD is J_\pi=0. It can be changed at Line 233-234.
% Silently runs mpt_init and (cvx_setup)


close all
clear
clc
addpath(genpath('../helper_codes'));
% Silently initialize MPT
evalc('mpt_init');

%%%%%%%%%%%%%%%%%%%%%%%%%% Modifiable parameters %%%%%%%%%%%%%%%%%%%%%%%%%%
%% Parameters: Initial positions of the robotR and robotG + Exponential means
%% Eg. 1: Parabolic path for mean of robotG
lambda_robotG_x=0.25;                                                      % lambda_x for robot G
lambda_robotG_y=0.45;                                                      % lambda_y for robot G 
x_robotR_init = [2.5;0];                                                   % Initial position for robot R x_R[0]
x_robotG_init = [1.5;0;-0.5;2];                                            % Initial position for robot G x_R[0]
u_robotR_min_x=-1.5;                                                       % Lower bound on U_x
u_robotR_max_x=1.5;                                                        % Upper bound on U_x
u_robotR_min_y=1;                                                          % Lower bound on U_y
u_robotR_max_y=4;                                                          % Upper bound on U_y
axis_vec=[-1,11,-1,11];                                                     % The figure axis
legendShow=[1,2];                                                          % Show legends for the plots mentioned in this array
%% Eg. 2: Another parabolic path for mean of robot G
% lambda_robotG_x=0.2;
% lambda_robotG_y=0.3;
% x_robotR_init = [0.5;1];
% x_robotG_init = [1.5;0.4;-0.5;-0.4];
% % Input space of RobotR
% u_robotR_min_x=1;
% u_robotR_max_x=4.5;
% u_robotR_min_y=-2.5;
% u_robotR_max_y=1;
% axis_vec=[-1,11,-4,8];                                                     % The figure axis
% legendShow=[1,3];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gap to match the lines of the scripts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Parameters for the simulation
time_horizon=9;                                                            % Time horizon of interest T (no. of time steps)
capture_set_box_half_edge=0.25;                                            % Half of the edge of the MeetSet, a/2
bounds_on_integral=400;                                                    %>400 means even 9 will work correctly
%% Parameters for the plots
timeBox=1;                                                                 % Create boxes describing time and probability of capture
create_plots_used_in_paper_only=1;                                         % 1 - Only relevant plots | 0 - All plots
savefigures_yes=0;                                                         % Save these figures in the path mentioned below
save_path_for_figures=strcat(pwd,'\Case2');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Parameters that are hard-coded
contour_plot_max=0.02;                                                     % colorbar max value
sampling_time_period=0.2;                                                  % Sampling time T_s
dimOfTextBox=[0.6 0.01 0.3 0.3];                                           % Time annotation location
%% Controllability matrix computation is hardcoded for a nx2 input matrix
%% RobotR has point mass dynamics - 2D system
A_robotR=[1,0;0,1];
B_robotR=blkdiag(sampling_time_period,sampling_time_period);
%% RobotG has Double integrator dynamics - 4D system
A_robotG=blkdiag([1,sampling_time_period;0,1],[1,sampling_time_period;0,1]);
B_robotG=blkdiag([sampling_time_period^2/2;sampling_time_period],[sampling_time_period^2/2;sampling_time_period]);

%%%%%%%%%%%%%%%%%%%%%%%%%%% Program Begins %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Decide if all plots are required or only ones relevant for the paper
if create_plots_used_in_paper_only==1                                      % Setting it to 1 will create only the plots required for the paper.
    vec_for_figures=[1,2,3,6,9];                                           % Time instants of interest (for plotting)
    fprintf('> Displaying only the relevant plots. Set create_plots_used_in_paper_only to 0\n\tto obtain all the plots.\n');
    fprintf('> Set timeBox to zero to reproduce the plots exactly.\n');
else                                                                       % Setting it to 0 will create all the plots
    vec_for_figures=1:time_horizon;                                        % Plot all figures
    fprintf('> Displaying all the plots. Set create_plots_used_in_paper_only to 1\n\tto obtain only the plots used in the paper.\n');
end
if savefigures_yes==1
    if isdir(save_path_for_figures)==0
        mkdir(save_path_for_figures);                                          % Create the folder if it isn't present
        disp('> Created a folder named Case2 in the pwd to save the figures to.')
    end
else
    fprintf('> Set savefigures_yes to 1 to save the plots in\n\t%s\n',save_path_for_figures);
end

%% Detect if CVX is there
is_cvx_installed=exist('cvx');
if is_cvx_installed>0
    open_loop_policy_generate=1;                                           % Generate open-loop policy and store it in the cell opt_policy
    fprintf('> Found CVX for computing the optimal control policy and\n\tinitial guess for optimization.\n');
    evalc('cvx_setup');
else                                                                       % If this is not true, then set open_loop_policy_generate=0
    open_loop_policy_generate=0;                                           % Generate open-loop policy and store it in the cell opt_policy
    fprintf('> You will need CVX to compute the optimal control policy and\n\tinitial guess for optimization.\n');
    fprintf('> Continuing without generating either.\n\n');
end

%% Environment creation  (Presentation purposes only)
x_min=axis_vec(1);
x_max=axis_vec(2);
y_min=axis_vec(3);
y_max=axis_vec(4);
x_env=x_min:0.01:x_max;
y_env=y_min:0.01:y_max;
% Create gridded environment for contour plot
grid_number=length(x_env);
if grid_number~=length(y_env)
    disp('Not a square axis_vec')
end
X_env=allcomb(x_env,y_env);

%% RobotR capture box
% Cuboid as opposed to square since the capture is defined only using position
box_infinity=10000;                                                                   % Definition of 'infinity' for the cuboid
capture_set_box_side_lengths=[capture_set_box_half_edge;box_infinity;capture_set_box_half_edge;box_infinity];   
% 4-D capture box
capture_set_box=Polyhedron('lb',-capture_set_box_side_lengths,'ub',capture_set_box_side_lengths);
% Ignoring velocity of the robotG
capture_set_box_2D=Polyhedron('lb',-capture_set_box_side_lengths([1,3]),'ub',capture_set_box_side_lengths([1,3]));

%% Optimization variables
prob_capture=zeros(1,time_horizon);                                        % Vector storing probability of capture
robotG_mean_position=x_robotG_init([1,3]);                                 % Vector storing mean position of robotG
robotR_optimal_position=x_robotR_init;                                     % Vector storing intercept position of robotR
elapsedTime=zeros(time_horizon+1,1);                                       % Stores time elapsed for each time instant and overall max
Ctrb_robotG=B_robotG;                                                      % Controllability matrix definition for robot G
Ctrb_robotR=B_robotR;                                                      % Controllability matrix definition for robot R

%% ProbC evaluation for each time instant
%Set timeBox to 0 to reproduce the figures without the annotations.
fprintf('> For more details on the plots, see the Figure 3 in the HSCC paper.\n> This simulation should take about 20 minutes to finish.\n> Uncomment line 25 in helper_codes/objective_function_exp_2D_CF.m\n\tto see the objective values during the optimization.\n> Solving Problem ProbC...\n\n');
for time_of_capture=1:time_horizon
    timerVal=tic;  
    
    %% Computation of the controllability matrices
    if time_of_capture>1
        Ctrb_robotG=[Ctrb_robotG,A_robotG*Ctrb_robotG(:,[end-1,end])];
        Ctrb_robotR=[Ctrb_robotR,A_robotR*Ctrb_robotR(:,[end-1,end])];    
    end
    
    %% Fwd reachability of robotR using (19) and MPT
    x_robotR_no_input_reachable=A_robotR^time_of_capture*x_robotR_init;
    u_robotR_box=Polyhedron('lb',repmat([u_robotR_min_x;u_robotR_min_y],time_of_capture,1),'ub',repmat([u_robotR_max_x;u_robotR_max_y],time_of_capture,1));
    % Fourier option selected to ensure that MPT does not convert Hrep unnecessarily to Vrep
    x_robotR_reachable=x_robotR_no_input_reachable+u_robotR_box.affineMap(Ctrb_robotR,'fourier');
    
    %% FSR reach set of robot G
    R_plus_box=Polyhedron('lb',zeros(1,size(Ctrb_robotG,2)),'ub',10000*ones(1,size(Ctrb_robotG,2))); % Domain of the acceleration    
    x_robotG_no_disturbance_reachable=A_robotG^time_of_capture*x_robotG_init;    
    x_robotG_no_disturbance_reachable_2D=x_robotG_no_disturbance_reachable([1,3]);
    % Fourier option selected to ensure that MPT does not convert Hrep unnecessarily to Vrep
    FSR_robotG_set=x_robotG_no_disturbance_reachable_2D+R_plus_box.affineMap(Ctrb_robotG([1,3],:),'fourier');
    % For display purposes, restricting the unbounded polytope to the axis
    % limits
    FSR_robotG_set_restricted=FSR_robotG_set.intersect(Polyhedron('lb',axis_vec([1,3]),'ub',axis_vec([2,4])));
    
    %% Robot G mean position computation for bookkeeping
    d_robotG_mean=repmat([1/lambda_robotG_x;1/lambda_robotG_y],time_of_capture,1);
    robotG_mean_state=x_robotG_no_disturbance_reachable+Ctrb_robotG*d_robotG_mean;
    robotG_mean_position=[robotG_mean_position,robotG_mean_state([1,3])];
    
    %% For numerical stability, ensure that FSRreach is incorporated into the %constraints (25) with epsilon=0+
    ProbC_feasible_set=x_robotR_reachable.intersect(FSR_robotG_set_restricted);
    A_inequalities=ProbC_feasible_set.A;
    b_inequalities=ProbC_feasible_set.b;
        
    %% Optimization problem --- Problem ProbC
    if ProbC_feasible_set.isEmptySet==0
        if is_cvx_installed>0
            %% Solve an optimization problem for projecting the mean to the reachable set
            cvx_begin quiet
                variable initial_guess_for_fmincon_cvx_variable(2)
                minimize (norm(initial_guess_for_fmincon_cvx_variable-robotG_mean_state([1,3])))
                A_inequalities*initial_guess_for_fmincon_cvx_variable <= b_inequalities;
            cvx_end
            initial_guess_for_fmincon=value(initial_guess_for_fmincon_cvx_variable);
        else
            %% Pick one of the vertices of the above polytope as the initial guess. 
            % It doesn't matter because of the convexity of the optimization problem.
            initial_guess_for_fmincon=ProbC_feasible_set.V(2,:)';
        end
        %% Use (30) to define the objective
        fun = @(x)-log(objective_function_exp_2D_CF(x,capture_set_box_half_edge,lambda_robotG_x,lambda_robotG_y,Ctrb_robotG,x_robotG_no_disturbance_reachable,bounds_on_integral));
        options=optimoptions('fmincon','Display','off');        
        %% Solve Problem ProbC
        [x_capture_point,prob_success_current] = fmincon(fun,initial_guess_for_fmincon,A_inequalities,b_inequalities,[],[],[],[],[],options);    
    else
        disp('Constraint set is empty');
        x_capture_point=x_robotR_reachable.V(1,:)';
        prob_success_current=Inf;
    end
    prob_capture(time_of_capture)=exp(-prob_success_current);              % - because maximization is required from fmincon; exp to undo the effect of log
    robotR_optimal_position=[robotR_optimal_position,x_capture_point];     % Optimal robotR position for this instant and the box
    
    %% Open-loop policy generation --- Problem ProbD
    if open_loop_policy_generate==1 && ProbC_feasible_set.isEmptySet==0
        displacement=x_capture_point-x_robotR_no_input_reachable;                % Equivalent to displacement=x_final-x_robotR_init;    
        cvx_begin quiet
            variable u(2*time_of_capture)
            %minimize (norm(u,2))                                          % Minimal control effort
            minimize 0                                                     % A feasible control policy
            u >= repmat([u_robotR_min_x;u_robotR_min_y],time_of_capture,1);
            u <= repmat([u_robotR_max_x;u_robotR_max_y],time_of_capture,1);
            Ctrb_robotR*u==displacement;
        cvx_end
        %disp(cvx_status)
        opt_policy{time_of_capture}=reshape(u,2,[]);
    else
        opt_policy{time_of_capture}=NaN;
    end
    
    elapsedTime(time_of_capture)=toc(timerVal);                            % Solution time to solve ProbC,ProbD
    if ProbC_feasible_set.isEmptySet==0
        fprintf('Solved at time t=%d to get success probability: %1.4f in %1.2f seconds\n',time_of_capture,exp(-prob_success_current),round(elapsedTime(time_of_capture)*100)/100);
    end
    
    %% Figure plotting --- To get it in the shape of the plots in the paper --- Figure 3
    if sum(time_of_capture==vec_for_figures)==0                            % Is this a plot of interest?
        continue                                                           % If not...
    end

    figure(time_of_capture);
    hold on;
    plot(robotG_mean_position(1,:),robotG_mean_position(2,:),'ko-','markersize',3,'linewidth',2); % RobotG mean positions so far    
    indx_opt_not=find(prob_capture(1:time_of_capture-1)<=10^-8);           % RobotR previous intercepts with zero probability of capture.
    plot(robotR_optimal_position(1,[1,1+indx_opt_not]),robotR_optimal_position(2,[1,1+indx_opt_not]),'rx','markersize',6,'linewidth',2);
    indx_opt=find(prob_capture(1:time_of_capture-1)>10^-8);                % RobotR previous intercepts with non-zero probability of capture. The current will be surrounded by box.
    plot(robotR_optimal_position(1,1+indx_opt),robotR_optimal_position(2,1+indx_opt),'rd','markersize',6,'linewidth',2); % Shift the points by 1 to accomodate the initial point
    if (time_of_capture==legendShow(1)) 
        % Show the legend for mean position of robot G and infeasible robot R position
        legend('Robot G mean position','Previous infeasible x_R[\tau]','location','North');            
        xlabel('Position (x)');
        ylabel('Position (y)');
    elseif (time_of_capture==legendShow(2)) 
        % Show the legend for optimal robot R position as well
        legend('Robot G mean position','Previous infeasible x_R[\tau]','Previous optimal x_R^\ast[\tau]','location','North');
        xlabel('Position (x)');
        ylabel('Position (y)');
    end
    if timeBox==1
        str = sprintf('Time: %2d\n Prob: %1.3f',time_of_capture,prob_capture(time_of_capture));
        a=annotation('textbox',dimOfTextBox,'String',str,'FitBoxToText','on');
        a.FontSize = 14;
    end
    
    %% Reach set plot
    % plot(FSR_reach,'Alpha',0.3,'Color','green');
    plot(x_robotR_reachable,'Color','blue','alpha',0.1);
    plot(x_capture_point+capture_set_box_2D,'alpha',0.5,'color','red');    % Optimal robotR position for this instant and the box
    plot(x_capture_point(1),x_capture_point(2),'ks','markerfacecolor',zeros(1,3));
    box on;
    grid on;
    grid minor;
    set(gca,'FontSize',20);
    axis(axis_vec);
    axis square    
    drawnow 
    % Figures are saved in the validation with Monte Carlo code
end

%% Max over time --- ProbB
timerVal=tic; 
[max_prob,time_of_capture_opt]=max(prob_capture);
elapsedTime(time_of_capture+1)=toc(timerVal);

%% Concluding message
% time_of_capture+1 to account for the fact that t starts from zero while indexing starts from 1.    
fprintf('\nThe optimal point of intercept is:\n\tTime of Intercept=%d,\n\tOptimal position of Robot R=(%1.1f,%1.1f),\n\tMean position of Robot G=(%1.1f,%1.1f),\n\tCapture Probability=%1.4f,\n\tComputation time=%f seconds.\n\n',time_of_capture_opt,robotR_optimal_position(1,time_of_capture_opt+1),robotR_optimal_position(2,time_of_capture_opt+1),robotG_mean_position(1,time_of_capture_opt+1),robotG_mean_position(2,time_of_capture_opt+1),max_prob,sum(elapsedTime));
if open_loop_policy_generate==1
    disp('The optimal open-loop policy is stored in the cell opt_policy.');
    fprintf('\n');
end

%% Capture probability over time plot --- Plotted only if required
if create_plots_used_in_paper_only==0
    figure(time_horizon+1);
    clf
    stem(1:time_horizon,prob_capture,'linewidth',2);
    xlabel('Time $(t)$','interpreter','latex');
    ylabel('$\mathrm{CapturePr}_{\bar{x}_R}(t,\bar{x}_R^\ast[t])$','interpreter','latex');
    title('Optimal capture probability attainable vs time of capture','interpreter','latex');
    set(gca,'FontSize',20);
    box on;
    grid on;
    if savefigures_yes
        print(strcat(save_path_for_figures,'\\SuccessProb.png'),'-dpng');
        savefig(strcat(save_path_for_figures,'\\SuccessProb.fig'));
    end
end
Case2_ExpNoise_MonteCarloValidation
