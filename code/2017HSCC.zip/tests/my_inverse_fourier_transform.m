function pdf_val=my_inverse_fourier_transform(point_of_interest,CF,bounds_on_integration)
% my_inverse_fourier_transform: Testing code for computing the inverse Fourier
%   transform of a characterisitic function of interest
%
% Input:
%   point_of_interest       : x, a row vector of appropriate dimensions
%   CF                      : Handle of the characteristic function whose
%                               IFT is of interest
%   bounds_on_integration   : Integration bounds (Approximating improper
%                               integral with a proper integral)
% Output:
%   Implements (3)
%
% Note:
%   Needs a point_of_interest which is a column vector in 2-D
%   Needs the 2-D characteristic CF to output in row vector format
    
    % -ve because C.F is Fourier(-t).
    fx = @(t1) integral(@(t2)CF(t1,t2).*exp(-1i*point_of_interest'*[repmat(t1,1,length(t2));t2]),-bounds_on_integration,bounds_on_integration);
    pdf_val_complex=(2*pi)^(-2)*integral(@(t1)fx(t1),-bounds_on_integration,bounds_on_integration,'ArrayValued',true);    
    pdf_val=real(pdf_val_complex);
    if abs(imag(pdf_val_complex))>10^-8
        fprintf('Errorneous pdfval:')
        disp(pdf_val_complex)
    elseif pdf_val<0
        fprintf('Expected +ve value:');
        disp(pdf_val);
        pdf_val=0;
    end
end
