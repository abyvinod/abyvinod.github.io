%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham                                   %
% Date: 2016-08-18                                                  %
% Purpose: > Testing CF_exponential                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear
clc
addpath(genpath('../helper_codes'))
%% Parameters for testing
% Environment
% y=-40:0.1:40;
y=-10:0.1:10;                                                              % Environment 1D
X_env=allcomb(y,y);                                                        % Environment 2D
% Exponential means
lambda_x=0.2;
lambda_y=0.3;
% Ensures the CF expression corresponds to product of two exponentials
B_robotG=[1,0;
          0,0;
          0,1;
          0,0];

%% Properties of Fourier transform
% CF(0)=1
fprintf('CF(0) should be 1 => %f\n',CF_exponential(0,0,lambda_x,lambda_y,B_robotG,[1;0;-2;0]))
% Taking inverse Fourier Transform of the CF at an arbitrary point
% This step takes lot of time since the Fourier transform is generally
% spread out (1/x decay).
bounds_on_integration=1000;
error_in_estimate=[];
fprintf('Testing the value estimated by IFT against the\noriginal value of the probability density function\n\n');
fprintf('Mode of the exponential is at the origin. Mean is (%1.2f,%1.2f)\n\n',lambda_x,lambda_y);
%% Timing data
elapsedTime=zeros(1,5);
%% Point 1
point_of_interest_x=0.04;
point_of_interest_y=0.06;
pdf_value=lambda_x*lambda_y*exp(-lambda_x*point_of_interest_x-lambda_y*point_of_interest_y);
timerVal=tic;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_exponential(t1,t2,lambda_x,lambda_y,B_robotG,[0;0;0;0]),bounds_on_integration);
elapsedTime(1)=toc(timerVal);
fprintf('1/5. Density at [%1.1e,%1.1e] should be %1.3e=> %1.3e\n\t\t inverse of CF computed in %2.2f seconds\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT,elapsedTime(1));
error_in_estimate=[error_in_estimate,abs(pdf_value_IFT-pdf_value)];
%% Point 2
point_of_interest_x=0.17;
point_of_interest_y=0.06;
pdf_value=lambda_x*lambda_y*exp(-lambda_x*point_of_interest_x-lambda_y*point_of_interest_y);
timerVal=tic;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_exponential(t1,t2,lambda_x,lambda_y,B_robotG,[0;0;0;0]),bounds_on_integration);
elapsedTime(2)=toc(timerVal);
fprintf('2/5. Density at [%1.1e,%1.1e] should be %1.3e=> %1.3e\n\t\t inverse of CF computed in %2.2f seconds\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT,elapsedTime(2));
error_in_estimate=[error_in_estimate,abs(pdf_value_IFT-pdf_value)];
%% Point 3
point_of_interest_x=0.003;
point_of_interest_y=0.008;
pdf_value=lambda_x*lambda_y*exp(-lambda_x*point_of_interest_x-lambda_y*point_of_interest_y);
timerVal=tic;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_exponential(t1,t2,lambda_x,lambda_y,B_robotG,[0;0;0;0]),bounds_on_integration);
elapsedTime(3)=toc(timerVal);
fprintf('3/5. Density at [%1.1e,%1.1e] should be %1.3e=> %1.3e\n\t\t inverse of CF computed in %2.2f seconds\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT,elapsedTime(3));
error_in_estimate=[error_in_estimate,abs(pdf_value_IFT-pdf_value)];
%% Point 4
point_of_interest_x=0.3;
point_of_interest_y=0.8;
pdf_value=lambda_x*lambda_y*exp(-lambda_x*point_of_interest_x-lambda_y*point_of_interest_y);
timerVal=tic;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_exponential(t1,t2,lambda_x,lambda_y,B_robotG,[0;0;0;0]),bounds_on_integration);
elapsedTime(4)=toc(timerVal);
fprintf('4/5. Density at [%1.1e,%1.1e] should be %1.3e=> %1.3e\n\t\t inverse of CF computed in %2.2f seconds\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT,elapsedTime(4));
error_in_estimate=[error_in_estimate,abs(pdf_value_IFT-pdf_value)];
%% Point 5
point_of_interest_x=1;
point_of_interest_y=1;
pdf_value=lambda_x*lambda_y*exp(-lambda_x*point_of_interest_x-lambda_y*point_of_interest_y);
timerVal=tic;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_exponential(t1,t2,lambda_x,lambda_y,B_robotG,[0;0;0;0]),bounds_on_integration);
elapsedTime(5)=toc(timerVal);
fprintf('5/5. Density at [%1.1e,%1.1e] should be %1.3e=> %1.3e\n\t\t inverse of CF computed in %2.2f seconds\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT,elapsedTime(5));
error_in_estimate=[error_in_estimate,abs(pdf_value_IFT-pdf_value)];
fprintf('Max error: %1.3e\n',max(error_in_estimate));
fprintf('Average FSRPD computation time: %1.3e\n',sum(elapsedTime)/5);
