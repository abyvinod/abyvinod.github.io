%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham                                   %
% Date: 2016-08-18                                                  %
% Purpose: > Testing CF_square_2D                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear
clc
addpath(genpath('../helper_codes'))
%% Parameters for testing
% Environment
y=-200:2:200;
X_env=allcomb(y,y);
location_center=[0;0];
box_half_side=0.23;

%% Properties of Fourier transform
% CF(0)=(2a)^2
fprintf('CF(0) should be %f => %f\n',4*box_half_side^2,CF_square_2D(0,0,location_center,box_half_side));
% Taking inverse Fourier Transform of the CF at an arbitrary point
% This step takes lot of time since the Fourier transform is generally
% spread out (1/x decay).
disp('Integration would be either close to zero or close to one.');
bounds_on_integration=1000;
fprintf('Checking if the given box is inside a square centered at origin with side:%1.2f\n',2*box_half_side);
%% Point 1
point_of_interest_x=0.2;
point_of_interest_y=0.2;
% max(a,b)<c iff a<c,b<c
pdf_value=max(abs([point_of_interest_x;point_of_interest_y]))<box_half_side;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_square_2D(t1,t2,location_center,box_half_side),bounds_on_integration);
fprintf('1/7. Indicator Value at [%1.2f,%1.2f] should be %d=> %1.3e\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT);
%% Point 2
point_of_interest_x=-0.21;
point_of_interest_y=0.14;
pdf_value=max(abs([point_of_interest_x;point_of_interest_y]))<box_half_side;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_square_2D(t1,t2,location_center,box_half_side),bounds_on_integration);
fprintf('2/7. Indicator Value at [%1.2f,%1.2f] should be %d=> %1.3e\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT);
%% Point 3
point_of_interest_x=0.2;
point_of_interest_y=-0.1;
pdf_value=max(abs([point_of_interest_x;point_of_interest_y]))<box_half_side;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_square_2D(t1,t2,location_center,box_half_side),bounds_on_integration);
fprintf('3/7. Indicator Value at [%1.2f,%1.2f] should be %d=> %1.3e\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT);
%% Point 4
point_of_interest_x=-0.02;
point_of_interest_y=-0.03;
pdf_value=max(abs([point_of_interest_x;point_of_interest_y]))<box_half_side;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_square_2D(t1,t2,location_center,box_half_side),bounds_on_integration);
fprintf('4/7. Indicator Value at [%1.2f,%1.2f] should be %d=> %1.3e\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT);
%% Point 5
point_of_interest_x=0;
point_of_interest_y=0;
pdf_value=max(abs([point_of_interest_x;point_of_interest_y]))<box_half_side;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_square_2D(t1,t2,location_center,box_half_side),bounds_on_integration);
fprintf('5/7. Indicator Value at [%1.2f,%1.2f] should be %d=> %1.3e\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT);
%% Point 6
point_of_interest_x=0.5;
point_of_interest_y=0.4;
pdf_value=max(abs([point_of_interest_x;point_of_interest_y]))<box_half_side;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_square_2D(t1,t2,location_center,box_half_side),bounds_on_integration);
fprintf('6/7. Indicator Value at [%1.2f,%1.2f] should be %d=> %1.3e\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT);
%% Point 7
point_of_interest_x=0.4;
point_of_interest_y=-0.3;
pdf_value=max(abs([point_of_interest_x;point_of_interest_y]))<box_half_side;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_square_2D(t1,t2,location_center,box_half_side),bounds_on_integration);
fprintf('7/7. Indicator Value at [%1.2f,%1.2f] should be %d=> %1.3e\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT);

%% Run this command to see how this Fourier Transform looks
% It is generally unimodal at the origin. To cause a shift in the origin,
% we need exponential decay multiplication.
disp('Visualizing the 2D-sinc');
CF_squareZvalue=[];
for indx=1:length(X_env)
    CF_squareZvalue(indx,:)=CF_square_2D(X_env(indx,1),X_env(indx,2),location_center,box_half_side);
end
clf;
surf(y,y,reshape(real(CF_squareZvalue),length(y),[]),'EdgeColor','none')
