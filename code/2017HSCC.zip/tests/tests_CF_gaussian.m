%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the programmer: Abraham                                   %
% Date: 2016-08-18                                                  %
% Purpose: > Testing CF_gaussian                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear
clc
addpath(genpath('../helper_codes'))
%% Parameters for testing
% Environment
% y=-40:0.1:40;
y=-10:0.1:10;                                                              % Environment 1D
X_env=allcomb(y,y);                                                        % Environment 2D
Sigma=[5,4;4,7];
mu=[2;1];

%% Properties of Fourier transform
% CF(0)=1
fprintf('CF(0) should be 1 => %f\n',CF_gaussian(0,0,mu,Sigma));
% Taking inverse Fourier Transform of the CF at an arbitrary point
bounds_on_integration=1000;
error_in_estimate=[];
fprintf('Testing the value estimated by IFT against the\noriginal value of the probability density function\n\n');
%% Timing data
elapsedTime=zeros(1,5);
elapsedTimePDF=zeros(1,5);
%% Point 1
point_of_interest_x=0.2;
point_of_interest_y=0.6;
timerVal=tic;
pdf_value=mvnpdf([point_of_interest_x;point_of_interest_y],mu,Sigma);
elapsedTimePDF(1)=toc(timerVal);
timerVal=tic;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_gaussian(t1,t2,mu,Sigma),bounds_on_integration);
elapsedTime(1)=toc(timerVal);
fprintf('1/5. Density at [%1.1e,%1.1e] should be %1.3e=> %1.3e\n\t\t inverse of CF computed in %2.2f seconds\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT,elapsedTime(1));
error_in_estimate=[error_in_estimate,abs(pdf_value_IFT-pdf_value)];
%% Point 2
point_of_interest_x=0.28;
point_of_interest_y=0.34;
timerVal=tic;
pdf_value=mvnpdf([point_of_interest_x;point_of_interest_y],mu,Sigma);
elapsedTimePDF(2)=toc(timerVal);
timerVal=tic;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_gaussian(t1,t2,mu,Sigma),bounds_on_integration);
elapsedTime(2)=toc(timerVal);
fprintf('2/5. Density at [%1.1e,%1.1e] should be %1.3e=> %1.3e\n\t\t inverse of CF computed in %2.2f seconds\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT,elapsedTime(2));
error_in_estimate=[error_in_estimate,abs(pdf_value_IFT-pdf_value)];
%% Point 3
point_of_interest_x=2;
point_of_interest_y=1;
timerVal=tic;
pdf_value=mvnpdf([point_of_interest_x;point_of_interest_y],mu,Sigma);
elapsedTimePDF(3)=toc(timerVal);
timerVal=tic;
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_gaussian(t1,t2,mu,Sigma),bounds_on_integration);
elapsedTime(3)=toc(timerVal);
fprintf('3/5. Density at [%1.1e,%1.1e] should be %1.3e=> %1.3e\n\t\t inverse of CF computed in %2.2f seconds\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT,elapsedTime(3));
error_in_estimate=[error_in_estimate,abs(pdf_value_IFT-pdf_value)];
%% Point 4
point_of_interest_x=7;
point_of_interest_y=3;
timerVal=tic;
pdf_value=mvnpdf([point_of_interest_x;point_of_interest_y],mu,Sigma);
elapsedTimePDF(4)=toc(timerVal);
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_gaussian(t1,t2,mu,Sigma),bounds_on_integration);
timerVal=tic;
elapsedTime(4)=toc(timerVal);
fprintf('4/5. Density at [%1.1e,%1.1e] should be %1.3e=> %1.3e\n\t\t inverse of CF computed in %2.2f seconds\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT,elapsedTime(4));
error_in_estimate=[error_in_estimate,abs(pdf_value_IFT-pdf_value)];
%% Point 5
point_of_interest_x=0.0;
point_of_interest_y=0.0;
timerVal=tic;
pdf_value=mvnpdf([point_of_interest_x;point_of_interest_y],mu,Sigma);
elapsedTimePDF(5)=toc(timerVal);
pdf_value_IFT=my_inverse_fourier_transform([point_of_interest_x;point_of_interest_y],@(t1,t2) CF_gaussian(t1,t2,mu,Sigma),bounds_on_integration);
timerVal=tic;
elapsedTime(5)=toc(timerVal);
fprintf('5/5. Density at [%1.1e,%1.1e] should be %1.3e=> %1.3e\n\t\t inverse of CF computed in %2.2f seconds\n',point_of_interest_x,point_of_interest_y,pdf_value,pdf_value_IFT,elapsedTime(5));
error_in_estimate=[error_in_estimate,abs(pdf_value_IFT-pdf_value)];
fprintf('Max error: %1.3e\n',max(error_in_estimate));
fprintf('Average FSRPD computation time (through CF): %1.3e\n',sum(elapsedTime)/5);
fprintf('Average FSRPD computation time (through PDF): %1.3e\n',sum(elapsedTimePDF)/5);