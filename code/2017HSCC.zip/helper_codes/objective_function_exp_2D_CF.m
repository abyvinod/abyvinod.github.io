function [f]=objective_function_exp_2D_CF(x,capture_box_half_edge,lambda_x,lambda_y,Ctrb_robotG,x_robotG_no_disturbance,bounds_on_integral)
% objective_function_exp_2D_CF: Calculate objective CapturePr (30) which is 
%   the probability for the position to be within the cuboid with vertices 
%   [-0.5,-0.5] and [0.5,0.5] centered about x.    
%
% Input:
%   x                       : Position of robotR (center of the CaptureSet
%   capture_box_half_edge   : Capture box side
%   lambda_x,lambda_y       : Means of the exponential in x,y directions
%   Ctrb_robotG             : Controllability matrix of robotG
%   x_robotG_no_disturbance : A^\tau x_G[0] term
%   bounds_on_integral      : Finite bounds for approximating the improper
%                               integral
% Output:
%   CapturePr using (26), (27), (28), and (30)
    myeps=10^-15;
    catchProb_t2_integrated=@(t1)integral(@(t2) CF_exponential(t1,t2,lambda_x,lambda_y,Ctrb_robotG,x_robotG_no_disturbance).*CF_square_2D(t1,t2,x,capture_box_half_edge),-bounds_on_integral,bounds_on_integral);
    catchProb=integral(@(t1)catchProb_t2_integrated(t1),-bounds_on_integral,bounds_on_integral,'ArrayValued',true)/(2*pi)/(2*pi);
    f=real(catchProb);
    % Can occur due numerical approximation of zero
    if f<=myeps
%         fprintf('\tSetting negative val:%1.4e to zero.\n',f);
        f=myeps;        
    end
%     fprintf('Achieved objective:%1.4e\n',f);
end
