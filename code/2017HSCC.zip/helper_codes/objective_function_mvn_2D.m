function [f]=objective_function_mvn_2D(x_robotR,capture_box_half_edge,mu_robotG,Sigma_robotG)
% objective_function_mvn_2D: Calculate objective CapturePr (24) which is 
% the probability for the position to be within the cuboid with edge 
% 2*capture_box_half_edge centered about x_robotR. The integration is done
% using mvncdf    
%
% Input:
%   x                       : Position of robotR (center of the CaptureSet
%   capture_box_half_edge   : Capture box side
%   mu_robotG               : Mean vector for robot G
%   Sigma_robotG            : Covariance matrix for robot G
% Output:
%   CapturePr using (24) and mvncdf
%
% Note:
%   Use options=statset('TolFun',1e-13); and pass options into mvncdf for
%   setting tolerance
    my_eps=10^-15;
    Y=mvncdf(x_robotR-[capture_box_half_edge;capture_box_half_edge],x_robotR+[capture_box_half_edge;capture_box_half_edge],mu_robotG,Sigma_robotG);
    f=max(Y,my_eps);   
    % Setting f<=my_eps to my_eps for log    
    % Can occur due numerical approximation of zero
    if f<=my_eps
%         fprintf('\tSetting negative val:%1.4e to zero.\n',f);
        f=my_eps;
    end
%     fprintf('Using mvncdf based objective:%1.4e\n',f);
end
