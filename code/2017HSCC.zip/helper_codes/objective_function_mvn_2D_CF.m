function [f]=objective_function_mvn_2D_CF(x,meet_set_capture_box_half_edge,mu_robotR,Sigma_robotG,bounds_on_integral)
% objective_function_mvn_2D_CF: Calculate objective CapturePr defined similar 
% to (30) which is the probability for the position to be within the cuboid 
% with edge 2*capture_box_half_edge centered about x_robotR.     
%
% Input:
%   x                       : Position of robotR (center of the CaptureSet
%   capture_box_half_edge   : Capture box side
%   mu_robotG               : Mean vector for robot G
%   Sigma_robotG            : Covariance matrix for robot G
%   bounds_on_integral      : Finite bounds for approximating the improper
%                               integral
% Output:
%   CapturePr using (16), (38), and (30)
    my_eps=10^-15;
    catchProb_t2_integrated=@(t1)integral(@(t2) CF_gaussian(t1,t2,mu_robotR,Sigma_robotG).*fourier_transform_2D_rect(t1,t2,x,meet_set_capture_box_half_edge),-bounds_on_integral,bounds_on_integral);
    catchProb=integral(@(t1)catchProb_t2_integrated(t1),-bounds_on_integral,bounds_on_integral,'ArrayValued',true)/(2*pi)/(2*pi);
    f=real(catchProb);
    % Setting f<=my_eps to my_eps for log
    % Can occur due numerical approximation of zero
    if f<=my_eps
%         fprintf('\tSetting negative val/close to zero val:%1.4e to zero.\n',f);
        f=my_eps;
    end
%     fprintf('Using CF based objective:%1.4e\n',f);
end
