function [f]=CF_square_2D(t1,t2,x,a)
% CF_square_2D: Fourier transform of 2D square function
%
% Input:
%   t1,t3                   : Fourier variables
%   x                       : Center of the 2D rectangle
%   a                       : Side of the square function
% Output:
%   Fourier transform value of 2D square function corresponding to (t1,t2)
% 
% Note:
% The fourier transform of a square box of half-edge 'a' and center x
% is 4*exp(-i <t,x>) sin(t1.a)sin(t2.a)/(t1.t2) with limit of
% sinc()sinc() being a^2. The exact equation is given in (28).
% From separable product and shift property in Table 13.1 and 
% \st{the last paragraph in Pg 7 in  Bracewell's textbook}, and Fourier 
% transform of rect given as 2*sin(w*a)/w in Example 4.4 in Signals and 
% system.
    myeps=10^-16;                                                          % Test for zero
    indx=find(abs(t2)<myeps);                                              % Store where t2 is zero to ensre no division by zero
    t2(indx)=1;                                                            % Dummy value for whenever t2 is zero; Will be overwritten
    if abs(t1)<myeps
        % t1=0 and t2~=0
        f=4*a*(exp(-1i*t2*x(2)).*sin(t2*a)./t2);
        % If t2=0 and t1=0
        f(indx)=4*a^2;
    else
        % t1~=0 and t2~=0
        T=[repmat(t1,1,length(t2));t2];
        f=4*exp(-1i*x'*T).*sin(T(1,:)*a).*sin(T(2,:)*a)./prod(T,1);
        % t2=0 but t1~=0
        f(indx)=4*a*exp(-1i*t1*x(1))*sin(t1*a)/t1;
    end    
end
