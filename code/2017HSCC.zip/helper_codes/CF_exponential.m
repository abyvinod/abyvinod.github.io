function [f]=CF_exponential(t1,t3,lambda_x,lambda_y,Ctrb_robotG,x_robotG_no_disturbance)
% CF_exponential: Characterisitic function of the marginal density of the 
%   FSRPD for Case 2 projected to the position space (Proposition 3 and (27))
%
% Input:
%   t1,t3                   : Fourier variables
%   lambda_x,lambda_y       : Means of the exponential in x,y directions
%   Ctrb_robotG             : Controllability matrix of robotG
%   x_robotG_no_disturbance : A^\tau x_G[0] term
% Output:
%   Characteristic function value of FSRPD for exponential noise corresponding to (t1,t2)

    dimension_of_inputs=2;                                                 
    % Extract \tau
    time_of_meeting=size(Ctrb_robotG,2)/dimension_of_inputs;
    
    %% Prepare for 2D integration
    % While integrating, CF_exponential is called with a fixed t1 and m
    length_of_t3=length(t3);
    % Integrating out the velocity components
    T=[repmat(t1,1,length_of_t3);
       zeros(1,length_of_t3);
       t3;
       zeros(1,length_of_t3)];

    %% Via independence in dimensions in essence S=Ctrb_robotG'*T;
    S=Ctrb_robotG'*T;
    Sx=S(1:2:end,1);
    Sy=S(2:2:end,:);
    
    %% Proposition 3 --- Complicated by vectorization involved in the integral function
    numerator_term=((lambda_x*lambda_y)^time_of_meeting)*exp(1i*x_robotG_no_disturbance'*T);
    denominator_term1=prod(-1i*Sx+repmat(lambda_x,time_of_meeting,1));
    if time_of_meeting==1
        % Only one term so no product
        denominator_term2=-1i*Sy+repmat(lambda_y,1,length_of_t3);
    else
        % product column-wise
        denominator_term2=prod(-1i*Sy+repmat(lambda_y,time_of_meeting,length_of_t3));
    end
    f=(numerator_term./denominator_term2)/denominator_term1;    
end
