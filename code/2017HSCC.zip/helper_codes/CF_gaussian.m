function [f]=CF_gaussian(t1,t2,mu,Sigma)
% CF_gaussian: Characterisitic function of the marginal density of the 
%   FSRPD for Case 2 projected to the position space (Proposition 1)
%
% Input:
%   t1,t3                   : Fourier variables
%   mu                      : Mean vector of the Gaussian (2D)
%   Sigma                   : Covariance matrix of the Gaussian (2D)
% Output:
%   Characteristic function value of FSRPD for Gaussian noise corresponding to (t1,t2)

    % mu is p x 1 column vector
    % Sigma is p x p positive definite matrix
    % t1 has to be scalar wheras t2 can be a vector
    T=[repmat(t1,1,length(t2));t2];
    f=exp(1i*mu'*T).*exp(-0.5*diag(T'*Sigma*T)');
end

    