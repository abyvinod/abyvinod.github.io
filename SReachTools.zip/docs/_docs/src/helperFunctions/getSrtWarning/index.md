---
layout: docs
title: getSrtWarning.m
---

```
getSrtWarning is a function.
    state = getSrtWarning(varargin)
```
