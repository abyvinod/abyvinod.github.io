---
name: Documentation
about: Updates to documentation webpage

---

Please provide the webpage link as well as the text/figure/content changes.

**System configuration**
 - Which OS are you using? [e.g.: Windows/iOS/Linux]
 - Which browser are you using?
